# 🚀 Быстрый старт - Цифровой Ангел

## Запуск приложения для разработки

### 1. Установка зависимостей
```bash
pip install -r requirements.txt
```

### 2. Запуск
```bash
python main.py
```

Приложение откроется в окне размером 360x640 пикселей (стандартный размер мобильного экрана).

---

## 📱 Сборка APK для Android

### Требования:
- Linux или macOS (Windows через WSL)
- Python 3.9+
- Buildozer

### Установка Buildozer (Linux):
```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-11-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev

pip3 install --user buildozer
export PATH=$PATH:~/.local/bin
```

### Сборка APK:
```bash
# Первая сборка (займет 30-60 минут)
buildozer android debug

# APK будет в папке bin/
```

### Установка на устройство:
```bash
adb install bin/angel-0.1-arm64-v8a-debug.apk
```

---

## 🎨 Структура приложения

- **Главный экран** - категории услуг (6 карточек)
- **Запись к врачу** - форма записи на прием
- **Вызов такси** - вызов такси с адресами
- **Оплата ЖКУ** - оплата коммунальных услуг
- **Видеозвонки** - список контактов для звонков
- **Проверка новостей** - проверка достоверности
- **Профиль** - настройки пользователя

---

## 🔧 Настройка

### Изменение темы:
В `main.py`:
```python
self.theme_cls.theme_style = "Dark"  # или "Light"
self.theme_cls.primary_palette = "Pink"
```

### Изменение размера окна:
В `main.py`:
```python
Window.size = (360, 640)  # Ширина x Высота
```

---

## 📝 Добавление нового экрана

1. Создайте файл `screens/new_screen.py`
2. Наследуйтесь от `MDScreen`
3. Добавьте экран в `main.py`:
```python
from screens.new_screen import NewScreen
sm.add_widget(NewScreen(name='new_screen'))
```

---

## 🐛 Решение проблем

### Ошибка импорта KivyMD:
```bash
pip install --upgrade kivymd
```

### Ошибка при сборке APK:
- Проверьте, что все зависимости в `requirements.txt`
- Убедитесь, что используете Linux/macOS
- Проверьте логи: `buildozer android debug -v`

### Приложение не запускается:
- Проверьте версию Python (должна быть 3.9+)
- Установите все зависимости: `pip install -r requirements.txt`

---

## 📚 Дополнительная документация

- `README.md` - полная документация
- `DEVELOPMENT_PLAN.md` - план разработки
- `VOICE_ASSISTANT_IDEAS.md` - идеи голосового помощника

---

**Удачи в разработке! 🎉**

