"""
Карусель виджетов здоровья
"""

from kivy.uix.carousel import Carousel
from kivy.uix.boxlayout import BoxLayout
from kivy.metrics import dp
from screens.health_widget import HealthWidget


class HealthCarousel(BoxLayout):
    """Карусель для переключения между виджетами здоровья"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = dp(10)
        self.size_hint_y = None
        self.height = dp(220)
        
        self.build_carousel()
    
    def build_carousel(self):
        """Построение карусели"""
        # Карусель
        self.carousel = Carousel(
            direction='right',
            loop=False,
            size_hint_y=None,
            height=dp(200)
        )
        
        # Виджет шагов
        steps_widget = HealthWidget(health_type='steps')
        self.carousel.add_widget(steps_widget)
        
        # Виджет пульса
        heart_rate_widget = HealthWidget(health_type='heart_rate')
        self.carousel.add_widget(heart_rate_widget)
        
        self.add_widget(self.carousel)
        
        # Индикаторы точек
        self.indicators = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(20),
            spacing=dp(8)
        )
        self.add_widget(self.indicators)
        
        self.create_indicators()
        self.carousel.bind(index=self.update_indicators)
    
    def create_indicators(self):
        """Создание индикаторов"""
        from kivy.uix.widget import Widget
        from kivy.graphics import Color, Ellipse
        
        for i in range(2):
            indicator = Widget(size_hint=(None, None), size=(dp(8), dp(8)))
            
            with indicator.canvas:
                Color(0.6, 0.4, 0.9, 1 if i == 0 else 0.3)
                indicator.circle = Ellipse(pos=indicator.pos, size=indicator.size)
            
            # Обновляем позицию круга при изменении позиции виджета (только один раз)
            def update_circle_pos(widget, value):
                if hasattr(widget, 'circle'):
                    widget.circle.pos = widget.pos
            
            # Используем Clock для отложенного обновления чтобы избежать циклов
            from kivy.clock import Clock
            indicator.bind(pos=lambda w, v: Clock.schedule_once(lambda dt: update_circle_pos(w, v), 0))
            self.indicators.add_widget(indicator)
    
    def update_indicators(self, instance, value):
        """Обновление индикаторов"""
        from kivy.graphics import Color
        
        for i, indicator in enumerate(reversed(self.indicators.children)):
            if hasattr(indicator, 'canvas') and indicator.canvas.children:
                # Ищем Color в canvas (он первый в списке)
                for instruction in indicator.canvas.children:
                    if isinstance(instruction, Color):
                        instruction.rgba = [0.6, 0.4, 0.9, 1 if i == value else 0.3]
                        break

