"""
Экран медицинской помощи
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp


class MedicalHelpScreen(MDScreen):
    """Экран медицинской помощи"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'medical_help'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Медицинская помощь")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2,
            md_bg_color=[0.9, 0.3, 0.3, 0.1]
        )
        info_card.bind(minimum_height=info_card.setter('height'))
        
        title = MDLabel(
            text="🚨 Экстренная помощь",
            theme_text_color="Error",
            font_style="H5",
            halign="left",
            size_hint_y=None,
            height=dp(40),
            bold=True
        )
        info_card.add_widget(title)
        
        emergency_label = MDLabel(
            text="При угрозе жизни немедленно звоните:",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(40),
            bold=True
        )
        info_card.add_widget(emergency_label)
        
        phone_label = MDLabel(
            text="📞 103 или 112",
            theme_text_color="Error",
            font_style="H4",
            halign="center",
            size_hint_y=None,
            height=dp(60),
            bold=True
        )
        info_card.add_widget(phone_label)
        
        content.add_widget(info_card)
        
        # Разделы
        sections = [
            {
                'icon': '🏥',
                'title': 'Как вызвать скорую помощь',
                'steps': [
                    '1. Наберите 103 или 112 с любого телефона',
                    '2. Сообщите диспетчеру адрес, где вы находитесь',
                    '3. Опишите симптомы и состояние больного',
                    '4. Назовите свой номер телефона',
                    '5. Не вешайте трубку - ждите указаний диспетчера',
                    '6. Встретьте скорую помощь у подъезда'
                ]
            },
            {
                'icon': '💊',
                'title': 'Неотложная помощь',
                'steps': [
                    '1. Если ситуация не критична, но нужен врач - звоните 103',
                    '2. Можно обратиться в поликлинику в часы работы',
                    '3. В нерабочее время - дежурный врач в поликлинике',
                    '4. Можно вызвать врача на дом через Госуслуги',
                    '5. При температуре выше 38°C - вызывайте врача'
                ]
            },
            {
                'icon': '📋',
                'title': 'Плановая медицинская помощь',
                'steps': [
                    '1. Запишитесь к врачу через Госуслуги',
                    '2. При себе иметь: паспорт, полис ОМС, СНИЛС',
                    '3. Приходите за 10-15 минут до приема',
                    '4. Возьмите результаты предыдущих анализов',
                    '5. Запишите вопросы к врачу заранее'
                ]
            },
            {
                'icon': '💉',
                'title': 'Вакцинация',
                'steps': [
                    '1. Запишитесь на вакцинацию через Госуслуги',
                    '2. Прививки от гриппа - бесплатно для пенсионеров',
                    '3. Прививка от COVID-19 - бесплатно',
                    '4. Прививки делают в поликлинике по месту жительства',
                    '5. Перед прививкой обязателен осмотр врача'
                ]
            },
            {
                'icon': '📞',
                'title': 'Полезные телефоны',
                'steps': [
                    'Скорая помощь: 103 или 112',
                    'Единая служба экстренных вызовов: 112',
                    'Горячая линия Минздрава: 8-800-200-0-200',
                    'Справочная поликлиники: уточните в вашей поликлинике'
                ]
            }
        ]
        
        for section in sections:
            section_card = self.create_section_card(section)
            content.add_widget(section_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_section_card(self, section):
        """Создание карточки раздела"""
        card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок
        header = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        
        icon_label = MDLabel(
            text=section['icon'],
            theme_text_color="Primary",
            font_style="H4",
            halign="left",
            size_hint_x=None,
            width=dp(50)
        )
        header.add_widget(icon_label)
        
        from kivy.core.window import Window
        title_width = Window.width - dp(40) - dp(40) - dp(50)  # padding + icon
        
        title_label = MDLabel(
            text=section['title'],
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            valign="middle",
            size_hint_x=1,
            bold=True,
            text_size=(title_width, None)
        )
        header.add_widget(title_label)
        
        card.add_widget(header)
        
        # Шаги
        step_width = Window.width - dp(40) - dp(40)  # padding content + padding card
        for step in section['steps']:
            step_label = MDLabel(
                text=step,
                theme_text_color="Secondary",
                font_style="Body2",
                halign="left",
                valign="top",
                size_hint_y=None,
                text_size=(step_width, None)
            )
            card.add_widget(step_label)
        
        return card

