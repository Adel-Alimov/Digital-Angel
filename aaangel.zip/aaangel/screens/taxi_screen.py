"""
Экран вызова такси
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.animation import Animation


class TaxiScreen(MDScreen):
    """Экран вызова такси"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'taxi'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Вызов такси")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Поле откуда
        from_field = MDTextField(
            hint_text="Откуда",
            mode="fill",
            icon_left="map-marker",
            size_hint_y=None,
            height=dp(60)
        )
        content.add_widget(from_field)
        
        # Поле куда
        to_field = MDTextField(
            hint_text="Куда",
            mode="fill",
            icon_left="map-marker",
            size_hint_y=None,
            height=dp(60)
        )
        content.add_widget(to_field)
        
        # Кнопка "Мое местоположение"
        location_btn = MDRaisedButton(
            text="Использовать мое местоположение",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.3, 0.8, 0.4, 1]
        )
        content.add_widget(location_btn)
        
        # Карточка с информацией
        info_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(120),
            radius=[dp(15), dp(15), dp(15), dp(15)]
        )
        
        info_label = MDLabel(
            text="Примерная стоимость: 250-350 руб.\nВремя ожидания: 5-10 минут",
            theme_text_color="Primary",
            font_style="Body1",
            halign="left",
            text_size=(None, None)
        )
        info_card.add_widget(info_label)
        content.add_widget(info_card)
        
        # Кнопка вызова такси
        call_btn = MDRaisedButton(
            text="Вызвать такси",
            size_hint_y=None,
            height=dp(60),
            md_bg_color=[0.8, 0.3, 0.6, 1],
            font_size=dp(18)
        )
        call_btn.bind(on_release=self.call_taxi)
        content.add_widget(call_btn)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1,
            text_size=(None, None)
        )
        header.add_widget(title_label)
        
        return header
    
    def call_taxi(self, instance):
        """Обработка вызова такси"""
        anim = Animation(md_bg_color=[0.6, 0.2, 0.5, 1], duration=0.1) + \
               Animation(md_bg_color=[0.8, 0.3, 0.6, 1], duration=0.1)
        anim.start(instance)
        
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Такси вызвано! Водитель приедет через 5-10 минут.",
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()

