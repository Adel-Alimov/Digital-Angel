"""
Виджет здоровья (шаги и пульс)
"""

from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.metrics import dp
from kivy.graphics import Color, Line, Rectangle
from kivy.animation import Animation
import random
from datetime import datetime, timedelta


class HealthWidget(MDCard):
    """Виджет здоровья с графиком"""
    
    def __init__(self, health_type='steps', **kwargs):
        super().__init__(**kwargs)
        self.health_type = health_type  # 'steps' или 'heart_rate'
        self.orientation = 'vertical'
        self.padding = dp(20)
        self.spacing = dp(10)
        self.radius = [dp(20), dp(20), dp(20), dp(20)]
        self.elevation = 2
        self.size_hint_y = None
        self.height = dp(200)
        
        self.build_widget()
        self.generate_sample_data()
        self.bind(on_touch_down=self.on_touch)
    
    def build_widget(self):
        """Построение виджета"""
        # Заголовок
        title_text = "Шаги" if self.health_type == 'steps' else "Пульс"
        title = MDLabel(
            text=title_text,
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        self.add_widget(title)
        
        # Основное значение
        self.value_label = MDLabel(
            text="0",
            theme_text_color="Primary",
            font_style="H4",
            halign="left",
            size_hint_y=None,
            height=dp(50)
        )
        self.add_widget(self.value_label)
        
        # Единица измерения
        unit_text = "шагов" if self.health_type == 'steps' else "уд/мин"
        unit = MDLabel(
            text=unit_text,
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(25)
        )
        self.add_widget(unit)
        
        # График
        self.graph_container = BoxLayout(
            size_hint_y=None,
            height=dp(80),
            padding=[0, dp(10), 0, 0]
        )
        self.add_widget(self.graph_container)
    
    def generate_sample_data(self):
        """Генерация тестовых данных"""
        if self.health_type == 'steps':
            # Генерируем данные шагов (5000-12000)
            self.current_value = random.randint(5000, 12000)
            self.data = [random.randint(5000, 12000) for _ in range(7)]
        else:
            # Генерируем данные пульса (60-100)
            self.current_value = random.randint(60, 100)
            self.data = [random.randint(60, 100) for _ in range(7)]
        
        self.value_label.text = str(self.current_value)
        self.draw_graph()
    
    def draw_graph(self):
        """Отрисовка графика"""
        self.graph_container.clear_widgets()
        
        from kivy.uix.widget import Widget
        
        graph = Widget()
        graph.size_hint = (1, 1)
        
        with graph.canvas:
            Color(0.6, 0.4, 0.9, 1)  # Фиолетовый цвет
            
            if len(self.data) > 0:
                width = graph.width if graph.width > 0 else 300
                height = graph.height if graph.height > 0 else 60
                
                min_val = min(self.data)
                max_val = max(self.data)
                range_val = max_val - min_val if max_val != min_val else 1
                
                points = []
                for i, value in enumerate(self.data):
                    x = (i / (len(self.data) - 1)) * width if len(self.data) > 1 else width / 2
                    normalized = (value - min_val) / range_val
                    y = normalized * height * 0.8 + height * 0.1
                    points.extend([x, y])
                
                if len(points) >= 4:
                    Line(points=points, width=2)
        
        graph.bind(size=self.update_graph)
        self.graph_container.add_widget(graph)
        self.graph = graph
    
    def update_graph(self, instance, value):
        """Обновление графика при изменении размера"""
        if hasattr(self, 'graph'):
            self.draw_graph()
    
    def update_data(self, data):
        """Обновление данных"""
        if self.health_type == 'steps':
            self.current_value = data.get('steps', 0)
        else:
            self.current_value = data.get('heart_rate', 0)
        
        self.value_label.text = str(self.current_value)
        self.draw_graph()
    
    def on_touch(self, instance, touch):
        """Обработка нажатия на виджет"""
        if self.collide_point(*touch.pos):
            # Переход на детальный экран
            from kivymd.app import MDApp
            app = MDApp.get_running_app()
            if app:
                screen_name = 'steps_detail' if self.health_type == 'steps' else 'heart_rate_detail'
                app.root.current = screen_name
            return True
        return False

