"""
Экран проверки новостей
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp


class NewsScreen(MDScreen):
    """Экран проверки новостей на достоверность"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'news'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Проверка новостей")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(120),
            radius=[dp(15), dp(15), dp(15), dp(15)]
        )
        
        info_label = MDLabel(
            text="Проверьте достоверность новости перед тем, как делиться ею",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            text_size=(None, None)
        )
        info_card.add_widget(info_label)
        content.add_widget(info_card)
        
        # Поле ввода новости
        news_field = MDTextField(
            hint_text="Вставьте текст новости или ссылку",
            mode="fill",
            multiline=True,
            size_hint_y=None,
            height=dp(150)
        )
        content.add_widget(news_field)
        
        # Кнопка проверки
        check_btn = MDRaisedButton(
            text="Проверить новость",
            size_hint_y=None,
            height=dp(60),
            md_bg_color=[0.6, 0.4, 0.9, 1],
            font_size=dp(18)
        )
        check_btn.bind(on_release=self.check_news)
        content.add_widget(check_btn)
        
        # Результат проверки (скрыт по умолчанию)
        self.result_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(100),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            opacity=0
        )
        
        self.result_label = MDLabel(
            text="",
            theme_text_color="Primary",
            font_style="Body1",
            halign="left",
            text_size=(None, None)
        )
        self.result_card.add_widget(self.result_label)
        content.add_widget(self.result_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1,
            text_size=(None, None)
        )
        header.add_widget(title_label)
        
        return header
    
    def check_news(self, instance):
        """Проверка новости"""
        from kivy.animation import Animation
        
        # Показываем результат
        self.result_label.text = "Новость проверена. Вероятность достоверности: 85%.\nИсточник: проверенный."
        self.result_card.md_bg_color = [0.8, 1.0, 0.8, 1]  # Зеленый фон
        
        anim = Animation(opacity=1, duration=0.3)
        anim.start(self.result_card)

