"""
Экран профиля пользователя с улучшенным дизайном
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.slider import Slider
from kivy.metrics import dp
from kivy.animation import Animation
from auth_manager import auth_manager
from utils.theme_switch import ThemeSwitch
from utils.settings_manager import settings_manager
from utils.screen_mixin import SettingsMixin


class ProfileScreen(MDScreen, SettingsMixin):
    """Экран профиля"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'profile'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Профиль")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        if auth_manager.is_authenticated():
            # Профиль авторизованного пользователя
            user = auth_manager.get_current_user()
            
            # Карточка профиля с анимацией
            profile_card = MDCard(
                orientation='vertical',
                padding=dp(25),
                spacing=dp(15),
                size_hint_y=None,
                height=dp(220),
                radius=[dp(25), dp(25), dp(25), dp(25)],
                elevation=3
            )
            
            # Аватар
            avatar_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(90))
            avatar_btn = MDIconButton(
                icon="account-circle",
                theme_icon_color="Primary",
                size_hint=(None, None),
                size=(dp(90), dp(90)),
                pos_hint={'center_x': 0.5}
            )
            avatar_layout.add_widget(avatar_btn)
            profile_card.add_widget(avatar_layout)
            
            # ФИО
            name_label = MDLabel(
                text=user.get('full_name', user.get('username', 'Пользователь')),
                theme_text_color="Primary",
                font_style="H5",
                halign="center",
                size_hint_y=None,
                height=dp(40)
            )
            profile_card.add_widget(name_label)
            
            # Email
            email_label = MDLabel(
                text=user.get('email', ''),
                theme_text_color="Secondary",
                font_style="Body2",
                halign="center",
                size_hint_y=None,
                height=dp(30)
            )
            profile_card.add_widget(email_label)
            
            content.add_widget(profile_card)
            
            # Личные данные
            personal_data_card = MDCard(
                orientation='vertical',
                padding=dp(20),
                spacing=dp(15),
                size_hint_y=None,
                radius=[dp(20), dp(20), dp(20), dp(20)],
                elevation=2
            )
            personal_data_card.bind(minimum_height=personal_data_card.setter('height'))
            
            personal_title = MDLabel(
                text="Личные данные",
                theme_text_color="Primary",
                font_style="H6",
                halign="left",
                size_hint_y=None,
                height=dp(35)
            )
            personal_data_card.add_widget(personal_title)
            
            # Данные
            data_items = [
                {"label": "Имя пользователя", "value": user.get('username', '')},
                {"label": "Email", "value": user.get('email', '')},
                {"label": "Телефон", "value": user.get('phone', 'Не указан')},
            ]
            
            for item in data_items:
                data_row = self.create_data_row(item["label"], item["value"])
                personal_data_card.add_widget(data_row)
            
            content.add_widget(personal_data_card)
            
            # Связи с сервисами
            services_card = MDCard(
                orientation='vertical',
                padding=dp(20),
                spacing=dp(15),
                size_hint_y=None,
                radius=[dp(20), dp(20), dp(20), dp(20)],
                elevation=2
            )
            services_card.bind(minimum_height=services_card.setter('height'))
            
            services_title = MDLabel(
                text="Связанные сервисы",
                theme_text_color="Primary",
                font_style="H6",
                halign="left",
                size_hint_y=None,
                height=dp(35)
            )
            services_card.add_widget(services_title)
            
            # Госуслуги
            gosuslugi_row = self.create_service_row(
                "Госуслуги",
                "Не подключено",
                "shield-account",
                [0.2, 0.6, 0.9, 1],
                self.connect_gosuslugi
            )
            services_card.add_widget(gosuslugi_row)
            
            # Приложение здоровья
            health_row = self.create_service_row(
                "Приложение здоровья",
                "Не подключено",
                "heart-pulse",
                [0.9, 0.3, 0.3, 1],
                self.connect_health
            )
            services_card.add_widget(health_row)
            
            content.add_widget(services_card)
            
            # Настройки
            settings_items = [
                {"icon": "cog", "title": "Настройки темы", "action": "theme"},
            ]
            
            for item in settings_items:
                setting_card = self.create_setting_item(item)
                content.add_widget(setting_card)
            
            # Режим для слабовидящих
            accessibility_card = self.create_accessibility_setting()
            content.add_widget(accessibility_card)
            
            # Размер текста
            font_size_card = self.create_font_size_setting()
            content.add_widget(font_size_card)
            
            # Остальные настройки
            other_settings = [
                {"icon": "bell", "title": "Уведомления", "action": None},
                {"icon": "shield-check", "title": "Безопасность", "action": None},
                {"icon": "help-circle", "title": "Помощь", "action": None},
                {"icon": "information", "title": "О приложении", "action": None},
            ]
            
            for item in other_settings:
                setting_card = self.create_setting_item(item)
                content.add_widget(setting_card)
            
            # Кнопка выхода
            logout_btn = MDRaisedButton(
                text="Выйти",
                size_hint_y=None,
                height=dp(50),
                md_bg_color=[0.9, 0.2, 0.2, 1]
            )
            logout_btn.bind(on_release=self.logout)
            content.add_widget(logout_btn)
        else:
            # Экран для неавторизованного пользователя
            login_card = MDCard(
                orientation='vertical',
                padding=dp(30),
                spacing=dp(20),
                size_hint_y=None,
                height=dp(250),
                radius=[dp(25), dp(25), dp(25), dp(25)],
                elevation=2
            )
            
            login_title = MDLabel(
                text="Войдите в аккаунт",
                theme_text_color="Primary",
                font_style="H5",
                halign="center",
                size_hint_y=None,
                height=dp(40)
            )
            login_card.add_widget(login_title)
            
            login_subtitle = MDLabel(
                text="Чтобы использовать все функции приложения",
                theme_text_color="Secondary",
                font_style="Body2",
                halign="center",
                size_hint_y=None,
                height=dp(30)
            )
            login_card.add_widget(login_subtitle)
            
            login_btn = MDRaisedButton(
                text="Войти",
                size_hint_y=None,
                height=dp(50),
                md_bg_color=[0.5, 0.3, 0.9, 1]
            )
            login_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'auth'))
            login_card.add_widget(login_btn)
            
            register_btn = MDRaisedButton(
                text="Зарегистрироваться",
                size_hint_y=None,
                height=dp(50),
                md_bg_color=[0.4, 0.4, 0.4, 1]
            )
            register_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'auth'))
            login_card.add_widget(register_btn)
            
            content.add_widget(login_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)]
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left"
        )
        header.add_widget(title_label)
        
        return header
    
    def create_data_row(self, label, value):
        """Создание строки данных"""
        from kivy.uix.boxlayout import BoxLayout
        
        row = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(40),
            spacing=dp(10)
        )
        
        label_widget = MDLabel(
            text=label + ":",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_x=0.4
        )
        row.add_widget(label_widget)
        
        value_widget = MDLabel(
            text=value,
            theme_text_color="Primary",
            font_style="Body1",
            halign="left",
            size_hint_x=0.6
        )
        row.add_widget(value_widget)
        
        return row
    
    def create_service_row(self, title, status, icon, color, callback):
        """Создание строки сервиса"""
        from kivy.uix.boxlayout import BoxLayout
        
        row = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(60),
            spacing=dp(15),
            padding=[dp(10), 0]
        )
        
        # Иконка
        icon_btn = MDIconButton(
            icon=icon,
            theme_icon_color="Custom",
            icon_color=color,
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        row.add_widget(icon_btn)
        
        # Информация
        info_layout = BoxLayout(orientation='vertical', spacing=dp(5))
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="Body1",
            halign="left",
            size_hint_y=None,
            height=dp(25)
        )
        info_layout.add_widget(title_label)
        
        status_label = MDLabel(
            text=status,
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(20)
        )
        info_layout.add_widget(status_label)
        
        row.add_widget(info_layout)
        
        # Кнопка подключения
        connect_btn = MDRaisedButton(
            text="Подключить",
            size_hint=(None, None),
            size=(dp(100), dp(35)),
            md_bg_color=color
        )
        connect_btn.bind(on_release=callback)
        row.add_widget(connect_btn)
        
        return row
    
    def create_setting_item(self, item):
        """Создание элемента настроек"""
        from kivy.uix.boxlayout import BoxLayout
        
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(60),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        
        icon_btn = MDIconButton(
            icon=item["icon"],
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        card.add_widget(icon_btn)
        
        title_label = MDLabel(
            text=item["title"],
            theme_text_color="Primary",
            font_style="Body1",
            halign="left"
        )
        card.add_widget(title_label)
        
        if item["action"] == "theme":
            # Переключатель темы с иконками
            theme_layout = BoxLayout(orientation='horizontal', spacing=dp(5), size_hint_x=None, width=dp(100))
            
            sun_icon = MDIconButton(
                icon="weather-sunny",
                theme_icon_color="Secondary",
                size_hint=(None, None),
                size=(dp(25), dp(25))
            )
            
            theme_switch = ThemeSwitch()
            theme_switch.active = self.is_dark_theme()
            theme_switch.bind(active=self.toggle_theme)
            
            moon_icon = MDIconButton(
                icon="weather-night",
                theme_icon_color="Secondary",
                size_hint=(None, None),
                size=(dp(25), dp(25))
            )
            
            theme_layout.add_widget(sun_icon)
            theme_layout.add_widget(theme_switch)
            theme_layout.add_widget(moon_icon)
            card.add_widget(theme_layout)
        else:
            arrow_btn = MDIconButton(
                icon="chevron-right",
                theme_icon_color="Secondary",
                size_hint=(None, None),
                size=(dp(30), dp(30))
            )
            card.add_widget(arrow_btn)
        
        return card
    
    def connect_gosuslugi(self, instance):
        """Подключение Госуслуг"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Подключение к Госуслугам временно недоступно.\nФункция будет доступна в следующих версиях приложения.",
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
    
    def connect_health(self, instance):
        """Подключение приложения здоровья"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Подключение к приложению здоровья временно недоступно.\nФункция будет доступна в следующих версиях приложения.",
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
    
    def is_dark_theme(self):
        """Проверка текущей темы"""
        from kivymd.app import MDApp
        app = MDApp.get_running_app()
        return app.theme_cls.theme_style == "Dark"
    
    def toggle_theme(self, instance, value):
        """Переключение темы"""
        from kivymd.app import MDApp
        app = MDApp.get_running_app()
        app.theme_cls.theme_style = "Dark" if value else "Light"
        # Обновляем экран
        self.clear_widgets()
        self.build_ui()
    
    def create_accessibility_setting(self):
        """Создание настройки режима для слабовидящих"""
        from kivy.uix.boxlayout import BoxLayout
        
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(60),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        
        icon_btn = MDIconButton(
            icon="eye",
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        card.add_widget(icon_btn)
        
        title_label = MDLabel(
            text="Режим для слабовидящих",
            theme_text_color="Primary",
            font_style="Body1",
            halign="left"
        )
        card.add_widget(title_label)
        
        # Переключатель
        accessibility_switch = ThemeSwitch()
        accessibility_switch.active = settings_manager.accessibility_mode
        accessibility_switch.bind(active=self.toggle_accessibility)
        card.add_widget(accessibility_switch)
        
        return card
    
    def create_font_size_setting(self):
        """Создание настройки размера текста"""
        from kivy.uix.boxlayout import BoxLayout
        
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(40),
            spacing=dp(15)
        )
        
        icon_btn = MDIconButton(
            icon="format-size",
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        header.add_widget(icon_btn)
        
        title_label = MDLabel(
            text="Размер текста",
            theme_text_color="Primary",
            font_style="Body1",
            halign="left"
        )
        header.add_widget(title_label)
        
        # Значение размера
        size_value_label = MDLabel(
            text=str(int(settings_manager.font_size_scale)),
            theme_text_color="Primary",
            font_style="H6",
            size_hint_x=None,
            width=dp(30),
            halign="center"
        )
        header.add_widget(size_value_label)
        
        card.add_widget(header)
        
        # Ползунок
        slider_layout = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(40),
            padding=[dp(10), 0, dp(10), 0]
        )
        
        # Минимальное значение
        min_label = MDLabel(
            text="1",
            theme_text_color="Secondary",
            font_style="Body2",
            size_hint_x=None,
            width=dp(30),
            halign="center"
        )
        slider_layout.add_widget(min_label)
        
        # Слайдер
        slider = Slider(
            min=1,
            max=10,
            value=settings_manager.font_size_scale,
            step=1,
            size_hint_x=1
        )
        
        def on_slider_value(instance, value):
            """Обработка изменения слайдера"""
            int_value = int(value)
            size_value_label.text = str(int_value)
            settings_manager.set_font_size(int_value)
            # Применяем размер текста сразу
            self.apply_font_size()
        
        slider.bind(value=on_slider_value)
        slider_layout.add_widget(slider)
        
        # Максимальное значение
        max_label = MDLabel(
            text="10",
            theme_text_color="Secondary",
            font_style="Body2",
            size_hint_x=None,
            width=dp(30),
            halign="center"
        )
        slider_layout.add_widget(max_label)
        
        card.add_widget(slider_layout)
        
        return card
    
    def toggle_accessibility(self, instance, value):
        """Переключение режима для слабовидящих"""
        settings_manager.set_accessibility_mode(value)
        self.apply_accessibility_mode()
    
    def apply_accessibility_mode(self):
        """Применение режима для слабовидящих"""
        from kivymd.app import MDApp
        app = MDApp.get_running_app()
        
        if settings_manager.accessibility_mode:
            # Режим для слабовидящих: увеличиваем контраст, размеры элементов
            app.theme_cls.primary_palette = "Blue"  # Более контрастный цвет
            app.theme_cls.accent_palette = "Blue"
        else:
            # Обычный режим
            app.theme_cls.primary_palette = "Purple"
            app.theme_cls.accent_palette = "Purple"
        
        # Применяем изменения ко всем виджетам без пересоздания UI
        self.apply_settings_to_widgets()
    
    def apply_font_size(self):
        """Применение размера текста"""
        # Применяем изменения ко всем виджетам без пересоздания UI
        self.apply_settings_to_widgets()
    
    
    def logout(self, instance):
        """Выход из аккаунта"""
        auth_manager.logout()
        self.clear_widgets()
        self.build_ui()
        self.manager.current = 'main'
