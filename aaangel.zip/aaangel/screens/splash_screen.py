"""
Экран загрузки с анимацией логотипа
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.label import MDLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.graphics import Color, Ellipse, Rectangle


class SplashScreen(MDScreen):
    """Экран загрузки с пульсирующим логотипом"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'splash'
        self.build_ui()
        self.start_animation()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.graphics import Color, Rectangle
        from kivy.uix.image import Image
        import os
        
        main_layout = BoxLayout(
            orientation='vertical',
            spacing=0
        )
        
        # Фон
        with main_layout.canvas.before:
            Color(0.1, 0.1, 0.15, 1)  # Темный фон
            main_layout.rect = Rectangle(pos=main_layout.pos, size=main_layout.size)
        
        main_layout.bind(
            pos=lambda w, v: setattr(main_layout.rect, 'pos', w.pos),
            size=lambda w, v: setattr(main_layout.rect, 'size', w.size)
        )
        
        # Центральный контейнер для логотипа
        logo_container = BoxLayout(
            orientation='vertical',
            spacing=dp(30),
            size_hint=(None, None),
            size=(dp(200), dp(250)),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Логотип - пытаемся загрузить изображение, если нет - используем графику
        logo_path = 'assets/logo.png'
        if os.path.exists(logo_path):
            # Используем изображение
            self.logo_widget = Image(
                source=logo_path,
                size_hint=(None, None),
                size=(dp(120), dp(120)),
                pos_hint={'center_x': 0.5},
                allow_stretch=True,
                keep_ratio=True
            )
        else:
            # Рисуем логотип программно
            self.logo_widget = BoxLayout(
                size_hint=(None, None),
                size=(dp(120), dp(120)),
                pos_hint={'center_x': 0.5}
            )
            
            # Рисуем логотип
            with self.logo_widget.canvas:
                # Внешний круг (пульсирующий) - синий с технологическими линиями
                Color(0.3, 0.5, 0.9, 1)  # Синий
                self.logo_circle = Ellipse(
                    pos=(0, 0),
                    size=(dp(120), dp(120))
                )
                
                # Внутренний круг (сердце) - оранжевый/персиковый
                Color(0.9, 0.6, 0.4, 1)  # Оранжевый/персиковый
                self.logo_heart = Ellipse(
                    pos=(dp(35), dp(35)),
                    size=(dp(50), dp(50))
                )
            
            self.logo_widget.bind(
                pos=self.update_logo,
                size=self.update_logo
            )
        
        logo_container.add_widget(self.logo_widget)
        
        # Название приложения
        app_name = MDLabel(
            text="Angel",
            theme_text_color="Primary",
            font_style="H3",
            bold=True,
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=dp(50),
            text_size=(None, None)
        )
        logo_container.add_widget(app_name)
        
        # Подзаголовок
        subtitle = MDLabel(
            text="Цифровой помощник",
            theme_text_color="Secondary",
            font_style="Body1",
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=dp(30),
            text_size=(None, None)
        )
        logo_container.add_widget(subtitle)
        
        main_layout.add_widget(logo_container)
        
        self.add_widget(main_layout)
        self.logo_container = logo_container
    
    def update_logo(self, instance, value):
        """Обновление позиции логотипа"""
        if hasattr(self, 'logo_circle') and instance.width > 0:
            self.logo_circle.pos = (instance.x, instance.y)
            self.logo_circle.size = (instance.width, instance.height)
        if hasattr(self, 'logo_heart') and instance.width > 0:
            self.logo_heart.pos = (
                instance.x + instance.width * 0.29,
                instance.y + instance.height * 0.29
            )
            self.logo_heart.size = (
                instance.width * 0.42,
                instance.height * 0.42
            )
    
    def start_animation(self):
        """Запуск анимации пульсации"""
        # Анимация пульсации логотипа
        def animate_logo(dt):
            import math
            import time
            t = time.time() % 2.0
            scale = 1.0 + 0.1 * math.sin(t * math.pi)
            new_size = (dp(120) * scale, dp(120) * scale)
            self.logo_widget.size = new_size
            self.logo_widget.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        
        Clock.schedule_interval(animate_logo, 0.05)
        
        # Переход на следующий экран через 2.5 секунды
        Clock.schedule_once(self.go_to_next_screen, 2.5)
    
    def go_to_next_screen(self, dt):
        """Переход на следующий экран"""
        from auth_manager import auth_manager
        if self.manager:
            if auth_manager.is_authenticated():
                self.manager.current = 'main'
            else:
                self.manager.current = 'auth'

