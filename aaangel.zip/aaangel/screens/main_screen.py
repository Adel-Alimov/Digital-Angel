"""
Главный экран приложения - обновленный дизайн
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton, MDRaisedButton
from kivymd.uix.label import MDLabel
from kivy.uix.gridlayout import GridLayout
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp, sp
from auth_manager import auth_manager
from utils.font_helper import get_font_size
from utils.screen_mixin import SettingsMixin


class MainScreen(MDScreen, SettingsMixin):
    """Главный экран с категориями услуг"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'main'
        self.build_ui()
    
    def on_enter(self):
        """Вызывается при переходе на экран"""
        # Обновляем UI при входе на экран
        if hasattr(self, 'children') and len(self.children) > 0:
            self.clear_widgets()
            self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.scrollview import ScrollView
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Минималистичный заголовок
        header = self.create_minimal_header()
        main_layout.add_widget(header)
        
        # Контент с прокруткой
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = BoxLayout(orientation='vertical', size_hint_y=None, padding=[dp(20), dp(20)])
        content.bind(minimum_height=content.setter('height'))
        
        # Минималистичное приветствие только по имени
        if auth_manager.is_authenticated():
            user = auth_manager.get_current_user()
            full_name = user.get('full_name', user.get('username', ''))
            # Берем имя (второе слово в ФИО, так как формат: Фамилия Имя Отчество)
            name_parts = full_name.split() if full_name else []
            if len(name_parts) >= 2:
                first_name = name_parts[1]  # Имя (второе слово)
            elif len(name_parts) == 1:
                first_name = name_parts[0]  # Если только одно слово, берем его
            else:
                first_name = user.get('username', '')
            greeting = MDLabel(
                text=first_name,
                theme_text_color="Primary",
                font_style="H4",
                size_hint_y=None,
                height=dp(50),
                halign="left",
                bold=True
            )
            # Применяем размер текста из настроек
            if hasattr(greeting, 'font_size'):
                greeting.font_size = get_font_size(greeting.font_size if greeting.font_size else sp(24))
            content.add_widget(greeting)
            content.add_widget(MDLabel(size_hint_y=None, height=dp(15)))  # Отступ
        
        # Сетка категорий
        grid = GridLayout(cols=2, spacing=dp(15), size_hint_y=None)
        grid.bind(minimum_height=grid.setter('height'))
        
        # Категории услуг
        categories = [
            {
                'icon': 'pill',
                'title': 'Таблетки',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'pills'
            },
            {
                'icon': 'test-tube',
                'title': 'Анализы',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'tests'
            },
            {
                'icon': 'heart-pulse',
                'title': 'Здоровье',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'health'
            },
            {
                'icon': 'book-open-variant',
                'title': 'Как записаться к врачу',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'doctor'
            },
            {
                'icon': 'account-heart',
                'title': 'Пенсия и льготы',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'benefits'
            },
            {
                'icon': 'hospital-building',
                'title': 'Медицинская помощь',
                'color': [0.5, 0.3, 0.9, 1],  # Фиолетовый
                'screen': 'medical_help'
            },
        ]
        
        for cat in categories:
            card = self.create_category_card(cat)
            grid.add_widget(card)
        
        content.add_widget(grid)
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        # Нижняя навигация
        nav = self.create_bottom_nav()
        main_layout.add_widget(nav)
        
        self.add_widget(main_layout)
    
    def create_minimal_header(self):
        """Создание минималистичного заголовка с анимацией"""
        from kivy.uix.boxlayout import BoxLayout
        from kivy.graphics import Color, Rectangle
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(100),
            padding=[dp(20), dp(15), dp(20), dp(15)]
        )
        
        # Градиентный фон заголовка
        with header.canvas.before:
            Color(0.5, 0.3, 0.9, 0.1)  # Легкий фиолетовый оттенок
            header.rect = Rectangle(pos=header.pos, size=header.size)
        
        header.bind(pos=lambda w, v: setattr(header.rect, 'pos', w.pos),
                   size=lambda w, v: setattr(header.rect, 'size', w.size))
        
        # Название приложения
        title = MDLabel(
            text="Angel",
            theme_text_color="Primary",
            font_style="H4",
            bold=True,
            halign="left"
        )
        header.add_widget(title)
        
        # Кнопка профиля
        profile_btn = MDIconButton(
            icon="account-circle",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(45), dp(45))
        )
        profile_btn.bind(on_release=lambda x: self.open_screen('profile'))
        header.add_widget(profile_btn)
        
        return header
    
    
    def create_category_card(self, category):
        """Создание карточки категории с анимацией"""
        from kivy.uix.boxlayout import BoxLayout
        
        card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(140),
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        
        # Проверка авторизации
        is_locked = not auth_manager.is_authenticated()
        if is_locked:
            card.md_bg_color = [0.15, 0.15, 0.2, 1]  # Темный фон для заблокированных
        
        # Анимация при нажатии
        def on_press(instance):
            if is_locked:
                self.show_login_required()
                return
            
            # Анимация нажатия
            anim = Animation(elevation=1, duration=0.1) + Animation(elevation=3, duration=0.1)
            anim.start(instance)
            Clock.schedule_once(lambda dt: self.open_screen(category['screen']), 0.2)
        
        card.bind(on_touch_down=lambda w, t: on_press(w) if w.collide_point(*t.pos) else False)
        
        # Иконка с анимацией пульсации
        icon_layout = BoxLayout(size_hint_y=None, height=dp(60))
        icon_btn = MDIconButton(
            icon=category['icon'],
            theme_icon_color="Custom",
            icon_color=category['color'] if not is_locked else [0.4, 0.4, 0.4, 1],
            size_hint=(None, None),
            size=(dp(60), dp(60)),
            pos_hint={'center_x': 0.5}
        )
        
        # Убираем анимацию пульсации чтобы избежать проблем с производительностью
        
        icon_layout.add_widget(icon_btn)
        card.add_widget(icon_layout)
        
        # Название с правильным выравниванием текста
        label = MDLabel(
            text=category['title'],
            theme_text_color="Primary" if not is_locked else "Secondary",
            font_style="Body1",
            halign="center",
            valign="middle",
            size_hint_y=None,
            height=dp(40),
            text_size=(card.width - dp(40), None)
        )
        # Обновляем text_size при изменении размера карточки
        def update_text_size(instance, value):
            if hasattr(instance, 'parent') and instance.parent:
                label.text_size = (instance.parent.width - dp(40), None)
        card.bind(width=update_text_size)
        card.add_widget(label)
        
        return card
    
    def create_bottom_nav(self):
        """Создание нижней навигации"""
        from kivy.uix.boxlayout import BoxLayout
        from kivy.graphics import Color, Rectangle
        
        nav = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(60),
            padding=[dp(20), dp(10)],
            spacing=dp(40)
        )
        
        # Фон навигации
        with nav.canvas.before:
            Color(0.1, 0.1, 0.15, 1)  # Темный фон
            nav.rect = Rectangle(pos=nav.pos, size=nav.size)
        
        nav.bind(pos=lambda w, v: setattr(nav.rect, 'pos', w.pos),
                 size=lambda w, v: setattr(nav.rect, 'size', w.size))
        
        # Кнопки навигации
        nav_buttons = [
            {'icon': 'view-dashboard', 'screen': 'main'},
            {'icon': 'chart-line', 'screen': 'main'},  # Статистика
            {'icon': 'account', 'screen': 'profile'},
        ]
        
        for btn_info in nav_buttons:
            btn = MDIconButton(
                icon=btn_info['icon'],
                theme_icon_color="Custom",
                icon_color=[0.5, 0.3, 0.9, 1] if btn_info['screen'] == 'main' else [0.5, 0.5, 0.5, 1],
                size_hint=(None, None),
                size=(dp(40), dp(40))
            )
            btn.bind(on_release=lambda x, s=btn_info['screen']: self.open_screen(s))
            nav.add_widget(btn)
        
        return nav
    
    def open_screen(self, screen_name):
        """Переход на другой экран"""
        self.manager.current = screen_name
    
    def show_login_required(self):
        """Показать сообщение о необходимости входа"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Войдите в аккаунт, чтобы использовать эту функцию",
            buttons=[
                MDRaisedButton(
                    text="Войти",
                    on_release=lambda x: (dialog.dismiss(), self.open_screen('auth'))
                ),
                MDRaisedButton(text="Отмена", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
