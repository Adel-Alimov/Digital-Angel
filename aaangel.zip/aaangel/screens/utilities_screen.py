"""
Экран оплаты ЖКУ
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp


class UtilitiesScreen(MDScreen):
    """Экран оплаты коммунальных услуг"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'utilities'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Оплата ЖКУ")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(100),
            radius=[dp(15), dp(15), dp(15), dp(15)]
        )
        
        info_label = MDLabel(
            text="Оплатите коммунальные услуги быстро и безопасно",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            text_size=(None, None)
        )
        info_card.add_widget(info_label)
        content.add_widget(info_card)
        
        # Поле лицевого счета
        account_field = MDTextField(
            hint_text="Лицевой счет",
            mode="fill",
            icon_left="identifier",
            size_hint_y=None,
            height=dp(60)
        )
        content.add_widget(account_field)
        
        # Поле суммы
        amount_field = MDTextField(
            hint_text="Сумма к оплате (руб.)",
            mode="fill",
            icon_left="currency-rub",
            size_hint_y=None,
            height=dp(60)
        )
        content.add_widget(amount_field)
        
        # Карточка с задолженностью
        debt_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(80),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            md_bg_color=[1.0, 0.9, 0.8, 1]
        )
        
        debt_label = MDLabel(
            text="Задолженность: 0 руб.",
            theme_text_color="Primary",
            font_style="H6",
            halign="left"
        )
        debt_card.add_widget(debt_label)
        content.add_widget(debt_card)
        
        # Кнопка оплаты
        pay_btn = MDRaisedButton(
            text="Оплатить",
            size_hint_y=None,
            height=dp(60),
            md_bg_color=[1.0, 0.5, 0.0, 1],
            font_size=dp(18)
        )
        pay_btn.bind(on_release=self.pay_utilities)
        content.add_widget(pay_btn)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1,
            text_size=(None, None)
        )
        header.add_widget(title_label)
        
        return header
    
    def pay_utilities(self, instance):
        """Обработка оплаты"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Оплата успешно выполнена! Чек отправлен на вашу почту.",
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()

