"""
Экран здоровья с вкладками и заметками для таблеток - ОБНОВЛЕННАЯ ВЕРСИЯ
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.tab import MDTabsBase, MDTabs
from kivymd.uix.floatlayout import MDFloatLayout
from kivy.metrics import dp
from kivy.clock import Clock
from auth_manager import auth_manager
import json
from datetime import datetime, timedelta
import random
import re


class MDTab(MDTabsBase, MDFloatLayout):
    """Вкладка"""
    pass


class TimePicker(MDBoxLayout):
    """Выпадающий список времени"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(200)
        self.spacing = dp(10)
        self.selected_time = "08:00"
        self.selected_hour = 8
        self.selected_minute = 0
        self.build_picker()
    
    def build_picker(self):
        """Построение выбора времени"""
        from kivy.uix.scrollview import ScrollView
        
        # Часы
        hours_scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, size_hint_x=0.5)
        hours_layout = MDBoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(5))
        hours_layout.bind(minimum_height=hours_layout.setter('height'))
        
        for h in range(24):
            hour_btn = MDFlatButton(
                text=f"{h:02d}",
                size_hint_y=None,
                height=dp(40),
                on_release=lambda x, hour=h: self.select_hour(hour)
            )
            hours_layout.add_widget(hour_btn)
        
        hours_scroll.add_widget(hours_layout)
        
        # Минуты
        minutes_scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, size_hint_x=0.5)
        minutes_layout = MDBoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(5))
        minutes_layout.bind(minimum_height=minutes_layout.setter('height'))
        
        for m in range(0, 60, 5):  # Каждые 5 минут
            minute_btn = MDFlatButton(
                text=f"{m:02d}",
                size_hint_y=None,
                height=dp(40),
                on_release=lambda x, minute=m: self.select_minute(minute)
            )
            minutes_layout.add_widget(minute_btn)
        
        minutes_scroll.add_widget(minutes_layout)
        
        # Выбранное время
        self.time_label = MDLabel(
            text="08:00",
            theme_text_color="Primary",
            font_style="H6",
            halign="center",
            size_hint_y=None,
            height=dp(40),
            size_hint_x=1
        )
        
        # Вертикальный layout
        main_layout = MDBoxLayout(orientation='vertical', spacing=dp(10))
        main_layout.add_widget(self.time_label)
        
        # Горизонтальный layout для прокрутки
        scroll_layout = MDBoxLayout(orientation='horizontal', spacing=dp(10))
        scroll_layout.add_widget(hours_scroll)
        scroll_layout.add_widget(minutes_scroll)
        main_layout.add_widget(scroll_layout)
        
        self.add_widget(main_layout)
    
    def select_hour(self, hour):
        """Выбор часа"""
        self.selected_hour = hour
        self.selected_time = f"{hour:02d}:{self.selected_minute:02d}"
        self.time_label.text = self.selected_time
    
    def select_minute(self, minute):
        """Выбор минуты"""
        self.selected_minute = minute
        self.selected_time = f"{self.selected_hour:02d}:{minute:02d}"
        self.time_label.text = self.selected_time


class HealthScreen(MDScreen):
    """Экран здоровья с вкладками"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'health'
        self.pill_notifications = {}  # Уведомления о таблетках
        self._ui_built = False
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        if self._ui_built:
            return
        self._ui_built = True
        
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок с кнопкой назад
        header = self.create_header("Здоровье")
        main_layout.add_widget(header)
        
        # Вкладки
        tabs = MDTabs()
        tabs.bind(on_tab_switch=self.on_tab_switch)
        tabs.size_hint_y = None
        tabs.height = dp(48)
        
        # Контейнер для контента вкладок
        self.tab_content = BoxLayout(orientation='vertical')
        self.tab_content.size_hint_y = 1
        
        # Создаем вкладки
        tab1 = MDTab()
        tab1.tab_label_text = 'Обзор'
        tabs.add_widget(tab1)
        
        tab2 = MDTab()
        tab2.tab_label_text = 'Таблетки'
        tabs.add_widget(tab2)
        
        tab3 = MDTab()
        tab3.tab_label_text = 'Анализы'
        tabs.add_widget(tab3)
        
        tab4 = MDTab()
        tab4.tab_label_text = 'Давление'
        tabs.add_widget(tab4)
        
        # Добавляем начальный контент
        self.tab_content.add_widget(self.create_overview_tab())
        
        main_layout.add_widget(tabs)
        main_layout.add_widget(self.tab_content)
        
        self.tabs = tabs
        self.current_tab = 0
        self.add_widget(main_layout)
        
        # Запускаем проверку уведомлений о таблетках
        Clock.schedule_interval(self.check_pill_notifications, 60)  # Каждую минуту
    
    def on_tab_switch(self, instance_tabs, instance_tab, instance_tab_label, tab_text):
        """Обработка переключения вкладок"""
        self.tab_content.clear_widgets()
        
        if tab_text == 'Обзор':
            self.tab_content.add_widget(self.create_overview_tab())
        elif tab_text == 'Таблетки':
            self.tab_content.add_widget(self.create_pills_tab())
        elif tab_text == 'Анализы':
            self.tab_content.add_widget(self.create_tests_tab())
        elif tab_text == 'Давление':
            self.tab_content.add_widget(self.create_pressure_tab())
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        # Кнопка назад
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_overview_tab(self):
        """Вкладка обзора здоровья"""
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Карточка общего состояния
        status_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(150),
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        
        status_title = MDLabel(
            text="Общее состояние",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        status_card.add_widget(status_title)
        
        status_value = MDLabel(
            text="Хорошее",
            theme_text_color="Primary",
            font_style="H4",
            halign="left",
            size_hint_y=None,
            height=dp(50)
        )
        status_card.add_widget(status_value)
        
        status_desc = MDLabel(
            text="Все показатели в норме",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        status_card.add_widget(status_desc)
        
        content.add_widget(status_card)
        
        # Прием таблеток
        pills_card = self.create_pills_overview_card()
        content.add_widget(pills_card)
        
        scroll.add_widget(content)
        return scroll
    
    def create_pills_overview_card(self):
        """Карточка приема таблеток для обзора"""
        pills = self.load_pills()
        
        card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        card.bind(minimum_height=card.setter('height'))
        
        title = MDLabel(
            text="Прием таблеток",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        card.add_widget(title)
        
        if pills:
            # Находим ближайший прием
            now = datetime.now()
            next_pill = None
            next_time = None
            
            for pill in pills:
                times = pill.get('time', '').split(',')
                for time_str in times:
                    time_str = time_str.strip()
                    try:
                        h, m = map(int, time_str.split(':'))
                        pill_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
                        if pill_time < now:
                            pill_time += timedelta(days=1)
                        
                        if next_time is None or pill_time < next_time:
                            next_time = pill_time
                            next_pill = pill
                    except:
                        continue
            
            if next_pill and next_time:
                time_diff = next_time - now
                hours = int(time_diff.total_seconds() // 3600)
                minutes = int((time_diff.total_seconds() % 3600) // 60)
                
                if hours > 0:
                    time_text = f"Через {hours} ч {minutes} мин"
                else:
                    time_text = f"Через {minutes} мин"
                
                pill_info = MDLabel(
                    text=f"{next_pill.get('name', 'Таблетка')} - {time_text}",
                    theme_text_color="Primary",
                    font_style="Body1",
                    halign="left",
                    size_hint_y=None,
                    height=dp(40),
                    text_size=(None, None)
                )
                card.add_widget(pill_info)
            else:
                no_pills = MDLabel(
                    text="Нет запланированных приемов",
                    theme_text_color="Secondary",
                    font_style="Body2",
                    halign="left",
                    size_hint_y=None,
                    height=dp(40)
                )
                card.add_widget(no_pills)
        else:
            # Кнопка добавить
            add_btn = MDRaisedButton(
                text="Добавить таблетку",
                size_hint_y=None,
                height=dp(50),
                md_bg_color=[0.5, 0.3, 0.9, 1]
            )
            add_btn.bind(on_release=lambda x: (self.tabs.switch_tab('Таблетки'), self.on_tab_switch(None, None, None, 'Таблетки')))
            card.add_widget(add_btn)
        
        return card
    
    def create_pills_tab(self):
        """Вкладка таблеток"""
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Кнопка добавления
        add_btn = MDRaisedButton(
            text="+ Добавить таблетку",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.5, 0.3, 0.9, 1]
        )
        add_btn.bind(on_release=self.show_add_pill_dialog)
        content.add_widget(add_btn)
        
        content.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
        
        # Список таблеток
        pills = self.load_pills()
        if pills:
            for pill in pills:
                pill_card = self.create_pill_card(pill)
                content.add_widget(pill_card)
        else:
            empty_label = MDLabel(
                text="Нет добавленных таблеток",
                theme_text_color="Secondary",
                font_style="Body1",
                halign="center",
                size_hint_y=None,
                height=dp(100)
            )
            content.add_widget(empty_label)
        
        scroll.add_widget(content)
        return scroll
    
    def create_tests_tab(self):
        """Вкладка анализов - БЕЗ ЭКГ"""
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # График анализов
        chart_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        chart_card.bind(minimum_height=chart_card.setter('height'))
        
        chart_title = MDLabel(
            text="График анализов",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        chart_card.add_widget(chart_title)
        
        # Простой график
        chart_widget = self.create_simple_chart("Холестерин", "мг/дл", [180, 175, 170, 185, 190, 185, 180])
        chart_card.add_widget(chart_widget)
        
        content.add_widget(chart_card)
        
        # Список анализов БЕЗ ЭКГ
        tests = [
            {"name": "Общий анализ крови", "date": "3 дня назад", "status": "Норма"},
            {"name": "Биохимия", "date": "1 неделя назад", "status": "Норма"},
        ]
        
        for test in tests:
            test_card = self.create_test_card(test)
            content.add_widget(test_card)
        
        scroll.add_widget(content)
        return scroll
    
    def create_pressure_tab(self):
        """Вкладка давления с возможностью записи"""
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Кнопка добавления измерения
        add_btn = MDRaisedButton(
            text="+ Записать давление",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.5, 0.3, 0.9, 1]
        )
        add_btn.bind(on_release=self.show_add_pressure_dialog)
        content.add_widget(add_btn)
        
        content.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
        
        # График давления
        chart_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        chart_card.bind(minimum_height=chart_card.setter('height'))
        
        chart_title = MDLabel(
            text="Артериальное давление",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        chart_card.add_widget(chart_title)
        
        # График давления из сохраненных данных
        pressure_chart = self.create_pressure_chart()
        chart_card.add_widget(pressure_chart)
        
        content.add_widget(chart_card)
        
        # Последние измерения
        measurements = self.load_pressure_measurements()
        if measurements:
            for measurement in measurements[:10]:  # Последние 10
                measure_card = self.create_measurement_card(measurement)
                content.add_widget(measure_card)
        else:
            empty_label = MDLabel(
                text="Нет записей о давлении",
                theme_text_color="Secondary",
                font_style="Body1",
                halign="center",
                size_hint_y=None,
                height=dp(100)
            )
            content.add_widget(empty_label)
        
        scroll.add_widget(content)
        return scroll
    
    def show_add_pressure_dialog(self, instance):
        """Диалог добавления измерения давления"""
        from kivymd.uix.dialog import MDDialog
        from kivy.uix.boxlayout import BoxLayout
        
        content = BoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None, height=dp(200))
        
        systolic_field = MDTextField(
            hint_text="Систолическое (верхнее)",
            mode="fill",
            size_hint_y=None,
            height=dp(50),
            input_filter='int'
        )
        content.add_widget(systolic_field)
        
        diastolic_field = MDTextField(
            hint_text="Диастолическое (нижнее)",
            mode="fill",
            size_hint_y=None,
            height=dp(50),
            input_filter='int'
        )
        content.add_widget(diastolic_field)
        
        pulse_field = MDTextField(
            hint_text="Пульс",
            mode="fill",
            size_hint_y=None,
            height=dp(50),
            input_filter='int'
        )
        content.add_widget(pulse_field)
        
        dialog = MDDialog(
            title="Записать давление",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(text="Отмена", on_release=lambda x: dialog.dismiss()),
                MDRaisedButton(
                    text="Сохранить",
                    on_release=lambda x: self.add_pressure(
                        systolic_field.text,
                        diastolic_field.text,
                        pulse_field.text,
                        dialog
                    )
                )
            ]
        )
        dialog.open()
    
    def add_pressure(self, systolic, diastolic, pulse, dialog):
        """Добавить измерение давления"""
        try:
            systolic = int(systolic) if systolic else 120
            diastolic = int(diastolic) if diastolic else 80
            pulse = int(pulse) if pulse else 70
        except:
            from kivymd.uix.dialog import MDDialog
            error_dialog = MDDialog(
                text="Введите корректные числа",
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: error_dialog.dismiss())]
            )
            error_dialog.open()
            return
        
        measurement = {
            'systolic': systolic,
            'diastolic': diastolic,
            'pulse': pulse,
            'date': datetime.now().strftime("%Y-%m-%d %H:%M"),
            'id': datetime.now().isoformat()
        }
        
        measurements = self.load_pressure_measurements()
        measurements.insert(0, measurement)  # Добавляем в начало
        self.save_pressure_measurements(measurements)
        
        dialog.dismiss()
        # Обновляем вкладку
        self.tab_content.clear_widgets()
        self.tab_content.add_widget(self.create_pressure_tab())
    
    def load_pressure_measurements(self):
        """Загрузить измерения давления"""
        try:
            with open('pressure.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Сортируем по дате (новые первые)
                return sorted(data, key=lambda x: x.get('date', ''), reverse=True)
        except:
            return []
    
    def save_pressure_measurements(self, measurements):
        """Сохранить измерения давления"""
        with open('pressure.json', 'w', encoding='utf-8') as f:
            json.dump(measurements, f, ensure_ascii=False, indent=2)
    
    def create_stat_card(self, label, value):
        """Создание карточки статистики"""
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(70),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        
        label_widget = MDLabel(
            text=label,
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_x=0.6,
            text_size=(None, None)
        )
        card.add_widget(label_widget)
        
        value_widget = MDLabel(
            text=value,
            theme_text_color="Primary",
            font_style="Body1",
            halign="right",
            size_hint_x=0.4,
            text_size=(None, None)
        )
        card.add_widget(value_widget)
        
        return card
    
    def create_pill_card(self, pill):
        """Создание карточки таблетки с отметкой приема"""
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=2
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок с кнопкой удаления
        header = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        
        name_label = MDLabel(
            text=pill.get('name', 'Таблетка'),
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_x=0.7,
            text_size=(None, None)
        )
        header.add_widget(name_label)
        
        delete_btn = MDIconButton(
            icon="delete",
            theme_icon_color="Error",
            size_hint=(None, None),
            size=(dp(35), dp(35)),
            pos_hint={'center_y': 0.5}
        )
        delete_btn.bind(on_release=lambda x, p=pill: self.delete_pill(p))
        header.add_widget(delete_btn)
        
        card.add_widget(header)
        
        # Дозировка
        dose_label = MDLabel(
            text=f"Дозировка: {pill.get('dose', '')}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(25),
            text_size=(None, None)
        )
        card.add_widget(dose_label)
        
        # Время приема
        time_label = MDLabel(
            text=f"Время: {pill.get('time', '')}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(25),
            text_size=(None, None)
        )
        card.add_widget(time_label)
        
        # Кнопка отметки приема
        taken = pill.get('taken_today', False)
        take_btn = MDRaisedButton(
            text="✓ Принято" if taken else "Отметить прием",
            size_hint_y=None,
            height=dp(40),
            md_bg_color=[0.3, 0.9, 0.3, 1] if taken else [0.5, 0.3, 0.9, 1]
        )
        take_btn.bind(on_release=lambda x, p=pill: self.mark_pill_taken(p))
        card.add_widget(take_btn)
        
        return card
    
    def mark_pill_taken(self, pill):
        """Отметить таблетку как принятую"""
        pills = self.load_pills()
        for p in pills:
            if p.get('id') == pill.get('id'):
                p['taken_today'] = True
                p['taken_at'] = datetime.now().isoformat()
                break
        self.save_pills(pills)
        
        # Обновляем вкладку
        self.tab_content.clear_widgets()
        self.tab_content.add_widget(self.create_pills_tab())
    
    def check_pill_notifications(self, dt):
        """Проверка уведомлений о таблетках"""
        pills = self.load_pills()
        now = datetime.now()
        
        for pill in pills:
            if pill.get('taken_today', False):
                continue
            
            times = pill.get('time', '').split(',')
            for time_str in times:
                time_str = time_str.strip()
                try:
                    h, m = map(int, time_str.split(':'))
                    pill_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
                    
                    # Уведомление через 5 минут после времени приема
                    notification_time = pill_time + timedelta(minutes=5)
                    
                    if now >= notification_time and now < notification_time + timedelta(minutes=1):
                        pill_id = pill.get('id')
                        if pill_id not in self.pill_notifications:
                            self.show_pill_notification(pill)
                            self.pill_notifications[pill_id] = True
                except:
                    continue
    
    def show_pill_notification(self, pill):
        """Показать уведомление о таблетке"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text=f"Не забудьте принять {pill.get('name', 'таблетку')}!\nВремя: {pill.get('time', '')}",
            buttons=[
                MDRaisedButton(
                    text="Принято",
                    on_release=lambda x: (self.mark_pill_taken(pill), dialog.dismiss())
                ),
                MDFlatButton(text="Напомнить позже", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
    
    def create_test_card(self, test):
        """Создание карточки анализа"""
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(100),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        
        name_label = MDLabel(
            text=test['name'],
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30),
            text_size=(None, None)
        )
        card.add_widget(name_label)
        
        info_layout = MDBoxLayout(orientation='horizontal', spacing=dp(20))
        
        date_label = MDLabel(
            text=test['date'],
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_x=0.5,
            text_size=(None, None)
        )
        info_layout.add_widget(date_label)
        
        status_label = MDLabel(
            text=test['status'],
            theme_text_color="Primary",
            font_style="Body1",
            halign="right",
            size_hint_x=0.5,
            text_size=(None, None)
        )
        info_layout.add_widget(status_label)
        
        card.add_widget(info_layout)
        
        return card
    
    def create_measurement_card(self, measurement):
        """Создание карточки измерения давления"""
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(80),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        
        # Дата
        date_str = measurement.get('date', '')
        if len(date_str) > 16:
            date_str = date_str[:16]  # Обрезаем если слишком длинная
        
        date_label = MDLabel(
            text=date_str,
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_x=0.3,
            text_size=(None, None)
        )
        card.add_widget(date_label)
        
        # Давление
        pressure_label = MDLabel(
            text=f"{measurement.get('systolic', 0)}/{measurement.get('diastolic', 0)}",
            theme_text_color="Primary",
            font_style="H6",
            halign="center",
            size_hint_x=0.4,
            text_size=(None, None)
        )
        card.add_widget(pressure_label)
        
        # Пульс
        pulse_label = MDLabel(
            text=f"Пульс: {measurement.get('pulse', 0)}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="right",
            size_hint_x=0.3,
            text_size=(None, None)
        )
        card.add_widget(pulse_label)
        
        return card
    
    def create_simple_chart(self, title, unit, data):
        """Создание простого графика"""
        from kivy.uix.widget import Widget
        from kivy.graphics import Color, Line, Rectangle
        
        chart_container = MDBoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None, height=dp(230))
        
        chart = Widget(size_hint_y=None, height=dp(200))
        
        # Сохраняем данные в виджете
        chart._chart_data = data
        chart._chart_title = title
        chart._chart_unit = unit
        
        def update_chart(instance, value):
            if not hasattr(chart, 'canvas') or chart.width == 0 or chart.height == 0:
                return
            
            chart.canvas.clear()
            
            # Параметры области графика
            padding = dp(15)
            graph_width = max(1, chart.width - (padding * 2))
            graph_height = max(1, chart.height - (padding * 2))
            graph_x = padding
            graph_y = padding
            
            # Получаем данные
            chart_data = getattr(chart, '_chart_data', data)
            if not chart_data:
                return
            
            max_val = max(chart_data) if chart_data else 1
            min_val = min(chart_data) if chart_data else 0
            range_val = max_val - min_val if max_val != min_val else 1
            
            with chart.canvas:
                # ФОН ГРАФИКА - рисуем первым
                Color(0.5, 0.3, 0.9, 0.3)
                Rectangle(
                    pos=(graph_x, graph_y),
                    size=(graph_width, graph_height)
                )
                
                # ЛИНИЯ ГРАФИКА - рисуем поверх фона
                if len(chart_data) > 1:
                    Color(0.5, 0.3, 0.9, 1)
                    points = []
                    step = graph_width / (len(chart_data) - 1)
                    
                    for i, val in enumerate(chart_data):
                        # X координата - равномерно распределена по ширине
                        x = graph_x + (i * step)
                        
                        # Y координата - нормализована и инвертирована
                        normalized = (val - min_val) / range_val if range_val > 0 else 0.5
                        # Инвертируем: высокие значения = верх графика, низкие = низ
                        y = graph_y + ((1 - normalized) * graph_height)
                        
                        points.extend([x, y])
                    
                    if len(points) >= 4:
                        Line(points=points, width=dp(2))
        
        chart.bind(size=update_chart, pos=update_chart)
        Clock.schedule_once(lambda dt: update_chart(chart, None), 0.3)
        
        label = MDLabel(
            text=f"{title} ({unit})",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(20),
            text_size=(None, None)
        )
        
        chart_container.add_widget(chart)
        chart_container.add_widget(label)
        
        return chart_container
    
    def create_pressure_chart(self):
        """Создание графика давления из сохраненных данных"""
        from kivy.uix.widget import Widget
        from kivy.graphics import Color, Line, Rectangle
        
        chart_container = MDBoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None, height=dp(230))
        
        chart = Widget(size_hint_y=None, height=dp(200))
        
        measurements = self.load_pressure_measurements()
        
        if measurements and len(measurements) > 1:
            recent = measurements[:7]
            systolic_data = [m.get('systolic', 120) for m in recent]
            diastolic_data = [m.get('diastolic', 80) for m in recent]
        else:
            systolic_data = [120, 125, 118, 122, 120]
            diastolic_data = [80, 82, 78, 80, 80]
        
        # Сохраняем данные в виджете
        chart._systolic_data = systolic_data
        chart._diastolic_data = diastolic_data
        
        def update_chart(instance, value):
            if not hasattr(chart, 'canvas') or chart.width == 0 or chart.height == 0:
                return
            
            chart.canvas.clear()
            
            # Параметры области графика
            padding = dp(15)
            graph_width = max(1, chart.width - (padding * 2))
            graph_height = max(1, chart.height - (padding * 2))
            graph_x = padding
            graph_y = padding
            
            # Диапазоны для нормализации
            systolic_min, systolic_max = 100, 150
            diastolic_min, diastolic_max = 60, 100
            
            # Получаем данные
            systolic_data = getattr(chart, '_systolic_data', [120, 125, 118, 122, 120])
            diastolic_data = getattr(chart, '_diastolic_data', [80, 82, 78, 80, 80])
            
            with chart.canvas:
                # ФОН ГРАФИКА - рисуем первым
                Color(0.5, 0.3, 0.9, 0.1)
                Rectangle(
                    pos=(graph_x, graph_y),
                    size=(graph_width, graph_height)
                )
                
                # СИСТОЛИЧЕСКОЕ ДАВЛЕНИЕ - красная линия
                if len(systolic_data) > 1:
                    Color(0.9, 0.3, 0.3, 1)
                    points = []
                    step = graph_width / (len(systolic_data) - 1)
                    
                    for i, val in enumerate(systolic_data):
                        x = graph_x + (i * step)
                        # Нормализуем в диапазоне 100-150
                        normalized = (val - systolic_min) / (systolic_max - systolic_min)
                        normalized = max(0, min(1, normalized))
                        # Инвертируем Y
                        y = graph_y + ((1 - normalized) * graph_height)
                        points.extend([x, y])
                    
                    if len(points) >= 4:
                        Line(points=points, width=dp(2))
                
                # ДИАСТОЛИЧЕСКОЕ ДАВЛЕНИЕ - синяя линия
                if len(diastolic_data) > 1:
                    Color(0.3, 0.3, 0.9, 1)
                    points = []
                    step = graph_width / (len(diastolic_data) - 1)
                    
                    for i, val in enumerate(diastolic_data):
                        x = graph_x + (i * step)
                        # Нормализуем в диапазоне 60-100
                        normalized = (val - diastolic_min) / (diastolic_max - diastolic_min)
                        normalized = max(0, min(1, normalized))
                        # Инвертируем Y
                        y = graph_y + ((1 - normalized) * graph_height)
                        points.extend([x, y])
                    
                    if len(points) >= 4:
                        Line(points=points, width=dp(2))
        
        chart.bind(size=update_chart, pos=update_chart)
        Clock.schedule_once(lambda dt: update_chart(chart, None), 0.3)
        
        label = MDLabel(
            text="Систолическое (красный) / Диастолическое (синий)",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(20),
            text_size=(None, None)
        )
        
        chart_container.add_widget(chart)
        chart_container.add_widget(label)
        
        return chart_container
    
    def show_add_pill_dialog(self, instance):
        """Показать диалог добавления таблетки с выпадающим списком времени"""
        from kivymd.uix.dialog import MDDialog
        from kivy.uix.boxlayout import BoxLayout
        
        content = BoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        name_field = MDTextField(
            hint_text="Название таблетки",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(name_field)
        
        dose_field = MDTextField(
            hint_text="Дозировка (например: 1 таблетка)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(dose_field)
        
        # Выпадающий список времени
        time_picker_label = MDLabel(
            text="Время приема:",
            theme_text_color="Primary",
            font_style="Body1",
            size_hint_y=None,
            height=dp(30)
        )
        content.add_widget(time_picker_label)
        
        time_picker = TimePicker()
        content.add_widget(time_picker)
        
        dialog = MDDialog(
            title="Добавить таблетку",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(text="Отмена", on_release=lambda x: dialog.dismiss()),
                MDRaisedButton(
                    text="Добавить",
                    on_release=lambda x: self.add_pill(
                        name_field.text,
                        dose_field.text,
                        time_picker.selected_time,
                        dialog
                    )
                )
            ]
        )
        dialog.open()
    
    def add_pill(self, name, dose, time, dialog):
        """Добавить таблетку"""
        if not name or not dose or not time:
            from kivymd.uix.dialog import MDDialog
            error_dialog = MDDialog(
                text="Заполните все поля",
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: error_dialog.dismiss())]
            )
            error_dialog.open()
            return
        
        pill = {
            'name': name,
            'dose': dose,
            'time': time,
            'id': datetime.now().isoformat(),
            'taken_today': False
        }
        
        pills = self.load_pills()
        pills.append(pill)
        self.save_pills(pills)
        
        dialog.dismiss()
        # Обновляем вкладку таблеток
        self.tab_content.clear_widgets()
        self.tab_content.add_widget(self.create_pills_tab())
    
    def delete_pill(self, pill):
        """Удалить таблетку"""
        pills = self.load_pills()
        pills = [p for p in pills if p.get('id') != pill.get('id')]
        self.save_pills(pills)
        
        # Обновляем вкладку таблеток
        self.tab_content.clear_widgets()
        self.tab_content.add_widget(self.create_pills_tab())
    
    def load_pills(self):
        """Загрузить список таблеток"""
        from utils.android_paths import get_data_path
        pills_file = get_data_path('pills.json')
        try:
            with open(pills_file, 'r', encoding='utf-8') as f:
                pills = json.load(f)
                # Сбрасываем отметки приема на новый день
                today = datetime.now().date().isoformat()
                for pill in pills:
                    if pill.get('taken_date') != today:
                        pill['taken_today'] = False
                return pills
        except:
            return []
    
    def save_pills(self, pills):
        """Сохранить список таблеток"""
        from utils.android_paths import get_data_path
        pills_file = get_data_path('pills.json')
        with open(pills_file, 'w', encoding='utf-8') as f:
            json.dump(pills, f, ensure_ascii=False, indent=2)
