"""
Экран детального просмотра пульса
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton
from kivymd.uix.label import MDLabel
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.graphics import Color, Line
import random


class HeartRateDetailScreen(MDScreen):
    """Экран детального просмотра пульса"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'heart_rate_detail'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Пульс")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Текущее значение
        current_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(120),
            radius=[dp(20), dp(20), dp(20), dp(20)]
        )
        
        current_value = MDLabel(
            text="72",
            theme_text_color="Primary",
            font_style="H2",
            halign="center",
            size_hint_y=None,
            height=dp(60)
        )
        current_card.add_widget(current_value)
        
        current_label = MDLabel(
            text="уд/мин",
            theme_text_color="Secondary",
            font_style="Body1",
            halign="center",
            size_hint_y=None,
            height=dp(30)
        )
        current_card.add_widget(current_label)
        
        content.add_widget(current_card)
        
        # График за день
        graph_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(300),
            radius=[dp(20), dp(20), dp(20), dp(20)]
        )
        
        graph_title = MDLabel(
            text="График за день",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(30)
        )
        graph_card.add_widget(graph_title)
        
        # График
        graph_container = BoxLayout(
            size_hint_y=None,
            height=dp(200),
            padding=[dp(10), dp(10)]
        )
        graph_card.add_widget(graph_container)
        
        self.draw_daily_graph(graph_container)
        content.add_widget(graph_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)]
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(40), dp(40))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left"
        )
        header.add_widget(title_label)
        
        return header
    
    def draw_daily_graph(self, container):
        """Отрисовка дневного графика"""
        from kivy.uix.widget import Widget
        
        graph = Widget()
        graph.size_hint = (1, 1)
        
        # Генерируем данные за день (24 часа)
        data = [random.randint(60, 100) for _ in range(24)]
        
        with graph.canvas:
            Color(0.5, 0.3, 0.9, 1)  # Фиолетовый
            
            width = 300
            height = 150
            min_val = min(data)
            max_val = max(data)
            range_val = max_val - min_val if max_val != min_val else 1
            
            points = []
            for i, value in enumerate(data):
                x = (i / (len(data) - 1)) * width if len(data) > 1 else width / 2
                normalized = (value - min_val) / range_val
                y = normalized * height * 0.8 + height * 0.1
                points.extend([x, y])
            
            if len(points) >= 4:
                Line(points=points, width=3)
        
        graph.bind(size=self.update_graph)
        container.add_widget(graph)
        self.graph = graph
        self.graph_data = data
    
    def update_graph(self, instance, value):
        """Обновление графика"""
        if hasattr(self, 'graph') and self.graph.width > 0:
            self.graph.canvas.clear()
            with self.graph.canvas:
                Color(0.5, 0.3, 0.9, 1)
                
                width = self.graph.width
                height = self.graph.height
                data = self.graph_data
                
                min_val = min(data)
                max_val = max(data)
                range_val = max_val - min_val if max_val != min_val else 1
                
                points = []
                for i, value in enumerate(data):
                    x = (i / (len(data) - 1)) * width if len(data) > 1 else width / 2
                    normalized = (value - min_val) / range_val
                    y = normalized * height * 0.8 + height * 0.1
                    points.extend([x, y])
                
                if len(points) >= 4:
                    Line(points=points, width=3)

