"""
Экран управления таблетками
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.clock import Clock
from datetime import datetime, timedelta
import json
import os

# Импорт для системных уведомлений
try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    print("Plyer не установлен. Системные уведомления недоступны.")


class TimePicker(MDBoxLayout):
    """Выпадающий список времени"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(200)
        self.spacing = dp(10)
        self.selected_time = "08:00"
        self.selected_hour = 8
        self.selected_minute = 0
        self.build_picker()
    
    def build_picker(self):
        """Построение выбора времени"""
        from kivy.uix.scrollview import ScrollView
        
        # Часы
        hours_scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, size_hint_x=0.5)
        hours_layout = MDBoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(5))
        hours_layout.bind(minimum_height=hours_layout.setter('height'))
        
        for h in range(24):
            hour_btn = MDFlatButton(
                text=f"{h:02d}",
                size_hint_y=None,
                height=dp(40),
                on_release=lambda x, hour=h: self.select_hour(hour)
            )
            hours_layout.add_widget(hour_btn)
        
        hours_scroll.add_widget(hours_layout)
        
        # Минуты
        minutes_scroll = ScrollView(do_scroll_x=False, do_scroll_y=True, size_hint_x=0.5)
        minutes_layout = MDBoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(5))
        minutes_layout.bind(minimum_height=minutes_layout.setter('height'))
        
        for m in range(0, 60, 5):  # Каждые 5 минут
            minute_btn = MDFlatButton(
                text=f"{m:02d}",
                size_hint_y=None,
                height=dp(40),
                on_release=lambda x, minute=m: self.select_minute(minute)
            )
            minutes_layout.add_widget(minute_btn)
        
        minutes_scroll.add_widget(minutes_layout)
        
        # Выбранное время
        self.time_label = MDLabel(
            text="08:00",
            theme_text_color="Primary",
            font_style="H6",
            halign="center",
            size_hint_y=None,
            height=dp(40),
            size_hint_x=1
        )
        
        # Вертикальный layout
        main_layout = MDBoxLayout(orientation='vertical', spacing=dp(10))
        main_layout.add_widget(self.time_label)
        
        # Горизонтальный layout для прокрутки
        scroll_layout = MDBoxLayout(orientation='horizontal', spacing=dp(10))
        scroll_layout.add_widget(hours_scroll)
        scroll_layout.add_widget(minutes_scroll)
        main_layout.add_widget(scroll_layout)
        
        self.add_widget(main_layout)
    
    def select_hour(self, hour):
        """Выбор часа"""
        self.selected_hour = hour
        self.selected_time = f"{hour:02d}:{self.selected_minute:02d}"
        self.time_label.text = self.selected_time
    
    def select_minute(self, minute):
        """Выбор минуты"""
        self.selected_minute = minute
        self.selected_time = f"{self.selected_hour:02d}:{minute:02d}"
        self.time_label.text = self.selected_time


class PillsScreen(MDScreen):
    """Экран управления таблетками"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'pills'
        self._ui_built = False
        self.notification_events = {}  # Хранилище событий уведомлений
        self.build_ui()
    
    def on_enter(self):
        """Вызывается при входе на экран"""
        # Перезапускаем уведомления при открытии экрана
        self.start_notification_check()
    
    def build_ui(self):
        """Построение интерфейса"""
        if self._ui_built:
            return
        self._ui_built = True
        
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Мои таблетки")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Кнопка добавления
        add_btn = MDRaisedButton(
            text="+ Добавить таблетку",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.5, 0.3, 0.9, 1]
        )
        add_btn.bind(on_release=self.show_add_pill_dialog)
        content.add_widget(add_btn)
        
        content.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
        
        # Список таблеток
        pills = self.load_pills()
        if pills:
            for pill in pills:
                pill_card = self.create_pill_card(pill)
                content.add_widget(pill_card)
        else:
            empty_label = MDLabel(
                text="Нет добавленных таблеток\nНажмите кнопку выше, чтобы добавить",
                theme_text_color="Secondary",
                font_style="Body1",
                halign="center",
                size_hint_y=None,
                height=dp(100)
            )
            content.add_widget(empty_label)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
        
        # Запускаем проверку уведомлений
        self.start_notification_check()
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_pill_card(self, pill):
        """Создание карточки таблетки"""
        taken = self.is_pill_taken_today(pill)
        
        # Изменяем цвет карточки, если таблетка принята
        card_color = [0.2, 0.7, 0.3, 0.3] if taken else [0.1, 0.1, 0.1, 1]
        
        # Параметры карточки
        card_params = {
            'orientation': 'vertical',
            'padding': dp(15),
            'spacing': dp(10),
            'size_hint_y': None,
            'radius': [dp(15), dp(15), dp(15), dp(15)],
            'elevation': 2,
            'md_bg_color': card_color
        }
        
        # Добавляем рамку только если таблетка принята
        if taken:
            card_params['line_color'] = [0.3, 0.9, 0.3, 1]
            card_params['line_width'] = 2
        
        card = MDCard(**card_params)
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок с кнопкой удаления
        header = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        
        from kivy.core.window import Window
        name_width = (Window.width - dp(30)) * 0.7 - dp(20)  # ширина экрана - padding - 70% - отступы
        
        # Добавляем иконку галочки, если таблетка принята
        name_layout = MDBoxLayout(orientation='horizontal', spacing=dp(5), size_hint_x=0.7)
        
        if taken:
            check_icon = MDLabel(
                text="✓",
                theme_text_color="Custom",
                text_color=[0.3, 0.9, 0.3, 1],
                font_style="H6",
                size_hint_x=None,
                width=dp(25)
            )
            name_layout.add_widget(check_icon)
        
        name_label = MDLabel(
            text=pill.get('name', 'Таблетка'),
            theme_text_color="Primary" if not taken else "Custom",
            text_color=[0.3, 0.9, 0.3, 1] if taken else None,
            font_style="H6",
            halign="left",
            valign="middle",
            size_hint_x=1,
            text_size=(name_width, None)
        )
        name_layout.add_widget(name_label)
        header.add_widget(name_layout)
        
        delete_btn = MDIconButton(
            icon="delete",
            theme_icon_color="Error",
            size_hint=(None, None),
            size=(dp(35), dp(35)),
            pos_hint={'center_y': 0.5}
        )
        delete_btn.bind(on_release=lambda x, p=pill: self.delete_pill(p))
        header.add_widget(delete_btn)
        
        card.add_widget(header)
        
        from kivy.core.window import Window
        card_text_width = Window.width - dp(30) - dp(30)  # padding content + padding card
        
        # Дозировка
        dose_label = MDLabel(
            text=f"Дозировка: {pill.get('dose', '')}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(card_text_width, None)
        )
        card.add_widget(dose_label)
        
        # Время приема
        time_label = MDLabel(
            text=f"Время: {pill.get('time', '')}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(card_text_width, None)
        )
        card.add_widget(time_label)
        
        # Показываем время приема, если таблетка принята
        if taken and pill.get('taken_at'):
            try:
                taken_time = datetime.fromisoformat(pill.get('taken_at'))
                taken_time_str = taken_time.strftime("%H:%M")
                taken_label = MDLabel(
                    text=f"Принято в: {taken_time_str}",
                    theme_text_color="Custom",
                    text_color=[0.3, 0.9, 0.3, 1],
                    font_style="Body2",
                    halign="left",
                    valign="top",
                    size_hint_y=None,
                    text_size=(card_text_width, None)
                )
                card.add_widget(taken_label)
            except:
                pass
        
        # Кнопка отметки приема
        take_btn = MDRaisedButton(
            text="✓ Принято" if taken else "Отметить прием",
            size_hint_y=None,
            height=dp(40),
            md_bg_color=[0.3, 0.9, 0.3, 1] if taken else [0.5, 0.3, 0.9, 1],
            disabled=taken
        )
        if not taken:
            take_btn.bind(on_release=lambda x, p=pill: self.mark_pill_taken(p))
        card.add_widget(take_btn)
        
        return card
    
    def show_add_pill_dialog(self, instance):
        """Показать диалог добавления таблетки"""
        from kivymd.uix.dialog import MDDialog
        from kivy.uix.boxlayout import BoxLayout
        
        content = BoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        name_field = MDTextField(
            hint_text="Название таблетки",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(name_field)
        
        dose_field = MDTextField(
            hint_text="Дозировка (например: 1 таблетка, 2 капсулы)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(dose_field)
        
        # Выпадающий список времени
        time_picker_label = MDLabel(
            text="Время приема:",
            theme_text_color="Primary",
            font_style="Body1",
            size_hint_y=None,
            height=dp(30)
        )
        content.add_widget(time_picker_label)
        
        time_picker = TimePicker()
        content.add_widget(time_picker)
        
        dialog = MDDialog(
            title="Добавить таблетку",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(text="Отмена", on_release=lambda x: dialog.dismiss()),
                MDRaisedButton(
                    text="Добавить",
                    on_release=lambda x: self.add_pill(
                        name_field.text,
                        dose_field.text,
                        time_picker.selected_time,
                        dialog
                    )
                )
            ]
        )
        dialog.open()
    
    def add_pill(self, name, dose, time, dialog):
        """Добавить таблетку"""
        if not name or not dose or not time:
            from kivymd.uix.dialog import MDDialog
            error_dialog = MDDialog(
                text="Заполните все поля",
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: error_dialog.dismiss())]
            )
            error_dialog.open()
            return
        
        pill = {
            'name': name,
            'dose': dose,
            'time': time,
            'id': datetime.now().isoformat(),
            'taken_today': False
        }
        
        pills = self.load_pills()
        pills.append(pill)
        self.save_pills(pills)
        
        dialog.dismiss()
        # Обновляем экран
        self._ui_built = False
        self.clear_widgets()
        self.build_ui()
        # Перезапускаем уведомления
        self.start_notification_check()
    
    def delete_pill(self, pill):
        """Удалить таблетку"""
        pills = self.load_pills()
        pill_id = pill.get('id')
        pills = [p for p in pills if p.get('id') != pill_id]
        self.save_pills(pills)
        
        # Останавливаем уведомления для удаленной таблетки
        for key in list(self.notification_events.keys()):
            if key.startswith(pill_id):
                Clock.unschedule(self.notification_events[key])
                del self.notification_events[key]
        
        # Обновляем экран
        self._ui_built = False
        self.clear_widgets()
        self.build_ui()
    
    def mark_pill_taken(self, pill):
        """Отметить таблетку как принятую"""
        pills = self.load_pills()
        for p in pills:
            if p.get('id') == pill.get('id'):
                p['taken_today'] = True
                p['taken_at'] = datetime.now().isoformat()
                p['taken_date'] = datetime.now().date().isoformat()
                # Останавливаем уведомления для этой таблетки
                pill_id = p.get('id')
                for key in list(self.notification_events.keys()):
                    if key.startswith(pill_id):
                        Clock.unschedule(self.notification_events[key])
                        del self.notification_events[key]
                break
        self.save_pills(pills)
        
        # Обновляем экран
        self._ui_built = False
        self.clear_widgets()
        self.build_ui()
        
        # Показываем подтверждение
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text=f"Таблетка '{pill.get('name', '')}' отмечена как принятая",
            buttons=[MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())]
        )
        dialog.open()
    
    def load_pills(self):
        """Загрузить список таблеток"""
        from utils.android_paths import get_data_path
        pills_file = get_data_path('pills.json')
        try:
            with open(pills_file, 'r', encoding='utf-8') as f:
                pills = json.load(f)
                # Сбрасываем отметки приема на новый день
                today = datetime.now().date().isoformat()
                for pill in pills:
                    taken_date = pill.get('taken_date')
                    if taken_date != today:
                        pill['taken_today'] = False
                        pill['taken_at'] = None
                        pill['taken_date'] = None
                return pills
        except:
            return []
    
    def is_pill_taken_today(self, pill):
        """Проверить, принята ли таблетка сегодня"""
        today = datetime.now().date().isoformat()
        taken_date = pill.get('taken_date')
        return taken_date == today and pill.get('taken_today', False)
    
    def save_pills(self, pills):
        """Сохранить список таблеток"""
        from utils.android_paths import get_data_path
        pills_file = get_data_path('pills.json')
        with open(pills_file, 'w', encoding='utf-8') as f:
            json.dump(pills, f, ensure_ascii=False, indent=2)
    
    def start_notification_check(self):
        """Запустить проверку уведомлений"""
        # Останавливаем все предыдущие события
        for event in self.notification_events.values():
            if event:
                Clock.unschedule(event)
        self.notification_events.clear()
        
        pills = self.load_pills()
        now = datetime.now()  # Используем время устройства
        
        for pill in pills:
            if self.is_pill_taken_today(pill):
                continue
            
            time_str = pill.get('time', '')
            if not time_str:
                continue
            
            try:
                h, m = map(int, time_str.split(':'))
                # Создаем время приема на сегодня
                pill_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
                
                # Если время приема уже прошло сегодня, планируем на завтра
                if pill_time < now:
                    pill_time = pill_time + timedelta(days=1)
                
                # Уведомление за 5 минут до приема
                notification_time = pill_time - timedelta(minutes=5)
                
                # Если уведомление должно быть в будущем
                if notification_time > now:
                    delay = (notification_time - now).total_seconds()
                    if delay > 0:
                        pill_id = pill.get('id')
                        event = Clock.schedule_once(
                            lambda dt, p=pill: self.show_pill_notification(p, True),
                            delay
                        )
                        self.notification_events[f"{pill_id}_reminder"] = event
                
                # Планируем уведомление в момент приема
                delay_to_pill = (pill_time - now).total_seconds()
                if delay_to_pill > 0:
                    pill_id = pill.get('id')
                    event = Clock.schedule_once(
                        lambda dt, p=pill: self.schedule_recurring_notifications(p, pill_time),
                        delay_to_pill
                    )
                    self.notification_events[f"{pill_id}_time"] = event
                    
            except Exception as e:
                print(f"Ошибка при планировании уведомления: {e}")
                continue
    
    def schedule_recurring_notifications(self, pill, pill_time):
        """Планировать повторяющиеся уведомления каждые 5 минут"""
        pill_id = pill.get('id')
        
        # Проверяем, не принята ли таблетка уже
        if self.is_pill_taken_today(pill):
            return
        
        # Показываем первое уведомление сразу
        self.show_pill_notification(pill, False)
        
        # Планируем повторные уведомления каждые 5 минут
        def schedule_next(dt, p_id=pill_id):
            # Загружаем актуальную информацию о таблетке
            pills = self.load_pills()
            current_pill = None
            for p in pills:
                if p.get('id') == p_id:
                    current_pill = p
                    break
            
            if not current_pill:
                # Таблетка удалена
                if f"{p_id}_recurring" in self.notification_events:
                    Clock.unschedule(self.notification_events[f"{p_id}_recurring"])
                    del self.notification_events[f"{p_id}_recurring"]
                return
            
            if not self.is_pill_taken_today(current_pill):
                self.show_pill_notification(current_pill, False)
                # Планируем следующее уведомление через 5 минут
                event = Clock.schedule_once(lambda dt: schedule_next(dt, p_id), 300)  # 300 секунд = 5 минут
                self.notification_events[f"{p_id}_recurring"] = event
            else:
                # Если таблетка принята, удаляем событие
                if f"{p_id}_recurring" in self.notification_events:
                    Clock.unschedule(self.notification_events[f"{p_id}_recurring"])
                    del self.notification_events[f"{p_id}_recurring"]
        
        # Планируем первое повторное уведомление через 5 минут
        event = Clock.schedule_once(lambda dt: schedule_next(dt, pill_id), 300)
        self.notification_events[f"{pill_id}_recurring"] = event
    
    def show_pill_notification(self, pill, is_reminder):
        """Показать уведомление о таблетке"""
        # Проверяем, не принята ли таблетка уже
        if self.is_pill_taken_today(pill):
            return
        
        pill_name = pill.get('name', 'таблетку')
        pill_time = pill.get('time', '')
        
        # Системное уведомление
        if PLYER_AVAILABLE:
            try:
                message = f"Не забудьте принять {pill_name}!"
                if is_reminder:
                    message = f"Через 5 минут нужно принять {pill_name}!"
                
                notification.notify(
                    title='Напоминание о таблетке',
                    message=f"{message}\nВремя приема: {pill_time}",
                    timeout=10,  # Уведомление будет видно 10 секунд
                    app_name='Цифровой Ангел'
                )
            except Exception as e:
                print(f"Ошибка при показе системного уведомления: {e}")
        
        # Диалог в приложении (если приложение открыто)
        try:
            from kivymd.uix.dialog import MDDialog
            message = f"Не забудьте принять {pill_name}!"
            if is_reminder:
                message = f"Через 5 минут нужно принять {pill_name}!"
            
            dialog = MDDialog(
                text=f"{message}\nВремя приема: {pill_time}",
                buttons=[
                    MDRaisedButton(
                        text="Принято",
                        on_release=lambda x, p=pill: (self.mark_pill_taken(p), dialog.dismiss())
                    ),
                    MDFlatButton(text="Напомнить позже", on_release=lambda x: dialog.dismiss())
                ]
            )
            dialog.open()
        except Exception as e:
            print(f"Ошибка при показе диалога: {e}")

