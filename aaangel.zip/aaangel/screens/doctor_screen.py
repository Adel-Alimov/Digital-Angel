"""
Экран просмотра инструкции "Как записаться к врачу" из MD файла
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
import re
import os


class DoctorScreen(MDScreen):
    """Экран просмотра инструкции записи к врачу из MD файла"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'doctor'
        self._ui_built = False
        from kivy.clock import Clock
        Clock.schedule_once(lambda dt: self.build_ui(), 0)
    
    def build_ui(self, *args):
        """Построение интерфейса"""
        if self._ui_built:
            return
        self._ui_built = True
        
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок с кнопкой назад
        header = self.create_header("Как записаться к врачу")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Загружаем и отображаем MD файл
        md_content = self.load_md_file()
        if md_content:
            self.render_markdown(content, md_content)
        else:
            error_label = MDLabel(
                text="Не удалось загрузить инструкцию",
                theme_text_color="Error",
                font_style="Body1",
                halign="center",
                size_hint_y=None,
                height=dp(100)
            )
            content.add_widget(error_label)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def load_md_file(self):
        """Загрузка MD файла"""
        from utils.android_paths import get_resource_path
        md_path = get_resource_path('doctor_guide.md')
        if os.path.exists(md_path):
            try:
                with open(md_path, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                print(f"Ошибка при чтении MD файла: {e}")
                return None
        return None
    
    def render_markdown(self, parent, md_text):
        """Рендеринг Markdown в виджеты KivyMD"""
        from kivy.core.window import Window
        
        lines = md_text.split('\n')
        i = 0
        card_width = Window.width - dp(40)  # padding content
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Заголовок H1
            if line.startswith('# '):
                title = line[2:].strip()
                title_label = MDLabel(
                    text=title,
                    theme_text_color="Primary",
                    font_style="H4",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width, None),
                    bold=True
                )
                title_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width, max(dp(40), size[1]))))
                parent.add_widget(title_label)
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
            
            # Заголовок H2
            elif line.startswith('## '):
                subtitle = line[3:].strip()
                subtitle_label = MDLabel(
                    text=subtitle,
                    theme_text_color="Primary",
                    font_style="H5",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width, None),
                    bold=True
                )
                subtitle_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width, max(dp(35), size[1]))))
                parent.add_widget(subtitle_label)
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(8)))
            
            # Заголовок H3
            elif line.startswith('### '):
                subsubtitle = line[4:].strip()
                subsubtitle_label = MDLabel(
                    text=subsubtitle,
                    theme_text_color="Primary",
                    font_style="H6",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width, None),
                    bold=True
                )
                subsubtitle_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width, max(dp(30), size[1]))))
                parent.add_widget(subsubtitle_label)
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(5)))
            
            # Горизонтальная линия
            elif line.startswith('---'):
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(20)))
            
            # Список (маркированный)
            elif line.startswith('- ') or line.startswith('* '):
                list_text = line[2:].strip()
                list_label = MDLabel(
                    text=f"• {list_text}",
                    theme_text_color="Primary",
                    font_style="Body1",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width - dp(20), None),
                    padding=[dp(20), 0, 0, 0]
                )
                list_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width - dp(20), max(dp(25), size[1]))))
                parent.add_widget(list_label)
            
            # Нумерованный список
            elif re.match(r'^\d+\.\s', line):
                list_text = re.sub(r'^\d+\.\s', '', line)
                list_label = MDLabel(
                    text=f"• {list_text}",
                    theme_text_color="Primary",
                    font_style="Body1",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width - dp(20), None),
                    padding=[dp(20), 0, 0, 0]
                )
                list_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width - dp(20), max(dp(25), size[1]))))
                parent.add_widget(list_label)
            
            # Обычный текст (параграф)
            elif line and not line.startswith('#'):
                # Обрабатываем жирный текст
                text = line
                text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Убираем ** для жирного
                text = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)  # Убираем ссылки, оставляем текст
                
                text_label = MDLabel(
                    text=text,
                    theme_text_color="Primary",
                    font_style="Body1",
                    halign="left",
                    size_hint_y=None,
                    text_size=(card_width, None)
                )
                text_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width, max(dp(25), size[1]))))
                parent.add_widget(text_label)
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(5)))
            
            # Пустая строка
            elif not line:
                parent.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
            
            i += 1
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        # Кнопка назад
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        # Заголовок
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1,
            text_size=(None, None)
        )
        header.add_widget(title_label)
        
        return header

