"""
Экран инструкции "Как записаться к врачу"
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp


class DoctorGuideScreen(MDScreen):
    """Экран инструкции записи к врачу через госуслуги"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'doctor_guide'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Как записаться к врачу")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2,
            md_bg_color=[0.5, 0.3, 0.9, 0.1]
        )
        info_card.bind(minimum_height=info_card.setter('height'))
        
        from kivy.core.window import Window
        card_width = Window.width - dp(40)  # padding content
        
        title = MDLabel(
            text="📋 Запись к врачу через Госуслуги",
            theme_text_color="Primary",
            font_style="H5",
            halign="left",
            valign="middle",
            size_hint_y=None,
            text_size=(card_width - dp(40), None),  # padding карточки
            bold=True
        )
        title.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width - dp(40), max(dp(40), size[1]))))
        info_card.add_widget(title)
        
        subtitle = MDLabel(
            text="Пошаговая инструкция для записи к врачу через портал Госуслуги",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(card_width - dp(40), None)
        )
        subtitle.bind(texture_size=lambda instance, size: setattr(instance, 'size', (card_width - dp(40), max(dp(50), size[1]))))
        info_card.add_widget(subtitle)
        
        content.add_widget(info_card)
        
        # Шаги инструкции
        steps = [
            {
                'number': '1',
                'title': 'Войдите на портал Госуслуги',
                'description': 'Откройте сайт gosuslugi.ru или приложение "Госуслуги" на телефоне. Войдите в свой аккаунт, используя логин и пароль. Если у вас нет аккаунта, зарегистрируйтесь - это займет несколько минут.'
            },
            {
                'number': '2',
                'title': 'Найдите раздел "Здоровье"',
                'description': 'В главном меню найдите раздел "Здоровье" или "Медицина". Нажмите на него, чтобы перейти к медицинским услугам.'
            },
            {
                'number': '3',
                'title': 'Выберите "Запись к врачу"',
                'description': 'В разделе "Здоровье" найдите опцию "Запись к врачу" или "Записаться на прием". Нажмите на эту кнопку.'
            },
            {
                'number': '4',
                'title': 'Выберите специалиста',
                'description': 'Выберите нужного врача из списка специалистов (терапевт, кардиолог, невролог и т.д.). Если вы не знаете, к какому врачу идти, выберите терапевта - он направит вас к нужному специалисту.'
            },
            {
                'number': '5',
                'title': 'Выберите поликлинику',
                'description': 'Выберите поликлинику, к которой вы прикреплены, или любую другую удобную для вас. Система покажет доступные варианты.'
            },
            {
                'number': '6',
                'title': 'Выберите дату и время',
                'description': 'Выберите удобную дату и время приема из доступных слотов. Свободные окна отмечены зеленым цветом.'
            },
            {
                'number': '7',
                'title': 'Подтвердите запись',
                'description': 'Проверьте все данные (врач, дата, время, поликлиника) и нажмите кнопку "Подтвердить запись". Вы получите подтверждение на телефон или email.'
            },
            {
                'number': '8',
                'title': 'Сохраните информацию',
                'description': 'Запишите или сохраните информацию о записи: дату, время, кабинет врача. За день до приема вам придет напоминание.'
            }
        ]
        
        for step in steps:
            step_card = self.create_step_card(step)
            content.add_widget(step_card)
        
        # Полезные советы
        tips_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2,
            md_bg_color=[0.3, 0.5, 0.9, 0.1]
        )
        tips_card.bind(minimum_height=tips_card.setter('height'))
        
        tips_title = MDLabel(
            text="💡 Полезные советы",
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            size_hint_y=None,
            height=dp(35),
            bold=True
        )
        tips_card.add_widget(tips_title)
        
        tips = [
            "• Записывайтесь заранее - свободные окна быстро разбирают",
            "• Если нужного времени нет, проверьте другие поликлиники",
            "• Можно записаться на прием для другого человека (родственника)",
            "• Отменить запись можно в том же разделе",
            "• При себе иметь паспорт и полис ОМС"
        ]
        
        from kivy.core.window import Window
        tip_width = Window.width - dp(40) - dp(40)  # padding content + padding card
        
        for tip in tips:
            tip_label = MDLabel(
                text=tip,
                theme_text_color="Primary",
                font_style="Body2",
                halign="left",
                valign="top",
                size_hint_y=None,
                text_size=(tip_width, None)
            )
            tip_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (tip_width, max(dp(30), size[1]))))
            tips_card.add_widget(tip_label)
        
        content.add_widget(tips_card)
        
        # Кнопка открыть Госуслуги
        open_btn = MDRaisedButton(
            text="Открыть Госуслуги",
            size_hint_y=None,
            height=dp(60),
            md_bg_color=[0.5, 0.3, 0.9, 1],
            font_size=dp(18)
        )
        open_btn.bind(on_release=self.open_gosuslugi)
        content.add_widget(open_btn)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_step_card(self, step):
        """Создание карточки шага"""
        from kivy.core.window import Window
        
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=1
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Номер шага
        number_label = MDLabel(
            text=step['number'],
            theme_text_color="Custom",
            text_color=[0.5, 0.3, 0.9, 1],
            font_style="H4",
            halign="center",
            valign="middle",
            size_hint_x=None,
            width=dp(50),
            bold=True
        )
        card.add_widget(number_label)
        
        # Текст шага
        text_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(8),
            size_hint_x=1
        )
        text_layout.bind(minimum_height=text_layout.setter('height'))
        
        # Ширина для текста = ширина экрана - отступы - номер - padding карточки
        text_width = Window.width - dp(50) - dp(30) - dp(30)  # номер + spacing + padding
        
        title_label = MDLabel(
            text=step['title'],
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(text_width, None),
            bold=True
        )
        title_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (text_width, max(dp(30), size[1]))))
        text_layout.add_widget(title_label)
        
        desc_label = MDLabel(
            text=step['description'],
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(text_width, None)
        )
        desc_label.bind(texture_size=lambda instance, size: setattr(instance, 'size', (text_width, max(dp(20), size[1]))))
        text_layout.add_widget(desc_label)
        
        card.add_widget(text_layout)
        
        return card
    
    def open_gosuslugi(self, instance):
        """Открыть Госуслуги"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Для записи к врачу откройте сайт gosuslugi.ru или приложение 'Госуслуги' на вашем телефоне.",
            buttons=[
                MDRaisedButton(text="Понятно", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()

