"""
Экран видеозвонков
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.animation import Animation


class VideoCallScreen(MDScreen):
    """Экран видеозвонков"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'video_call'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Видеозвонки")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            height=dp(100),
            radius=[dp(15), dp(15), dp(15), dp(15)]
        )
        
        info_label = MDLabel(
            text="Позвоните родственникам или друзьям",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            text_size=(None, None)
        )
        info_card.add_widget(info_label)
        content.add_widget(info_card)
        
        # Список контактов
        contacts = [
            {"name": "Дочь Мария", "status": "Онлайн"},
            {"name": "Сын Иван", "status": "Офлайн"},
            {"name": "Внучка Аня", "status": "Онлайн"},
        ]
        
        for contact in contacts:
            contact_card = self.create_contact_card(contact)
            content.add_widget(contact_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', 'main'))
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1,
            text_size=(None, None)
        )
        header.add_widget(title_label)
        
        return header
    
    def create_contact_card(self, contact):
        """Создание карточки контакта"""
        from kivy.uix.boxlayout import BoxLayout
        
        card = MDCard(
            orientation='horizontal',
            padding=dp(15),
            spacing=dp(15),
            size_hint_y=None,
            height=dp(80),
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=2
        )
        
        # Аватар
        avatar = MDIconButton(
            icon="account-circle",
            theme_icon_color="Primary",
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        card.add_widget(avatar)
        
        # Информация
        info_layout = BoxLayout(orientation='vertical', spacing=dp(5))
        
        name_label = MDLabel(
            text=contact["name"],
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            text_size=(None, None)
        )
        info_layout.add_widget(name_label)
        
        status_label = MDLabel(
            text=contact["status"],
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            text_size=(None, None)
        )
        info_layout.add_widget(status_label)
        
        card.add_widget(info_layout)
        
        # Кнопка звонка
        call_btn = MDRaisedButton(
            icon="video",
            size_hint=(None, None),
            size=(dp(50), dp(50)),
            md_bg_color=[0.3, 0.8, 0.4, 1],
            rounded_button=True  # Круглая кнопка
        )
        call_btn.bind(on_release=lambda x: self.start_call(contact["name"]))
        card.add_widget(call_btn)
        
        return card
    
    def start_call(self, contact_name):
        """Начало видеозвонка"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text=f"Вызов {contact_name}...\n\n(В будущем здесь будет интеграция с видеозвонками)",
            buttons=[
                MDRaisedButton(text="Отмена", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()

