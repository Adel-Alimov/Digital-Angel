"""
Экран авторизации и регистрации - обновленный
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.animation import Animation
from kivy.clock import Clock
from auth_manager import auth_manager


class AuthScreen(MDScreen):
    """Экран авторизации"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'auth'
        self.is_login = True  # True - вход, False - регистрация
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок с кнопкой назад
        header = self.create_header()
        main_layout.add_widget(header)
        
        # Контент с прокруткой
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(30), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Заголовок с анимацией
        title = MDLabel(
            text="Angel",
            theme_text_color="Primary",
            font_style="H3",
            halign="center",
            size_hint_y=None,
            height=dp(60)
        )
        content.add_widget(title)
        
        subtitle = MDLabel(
            text="Вход" if self.is_login else "Регистрация",
            theme_text_color="Secondary",
            font_style="H6",
            halign="center",
            size_hint_y=None,
            height=dp(40)
        )
        content.add_widget(subtitle)
        
        content.add_widget(MDLabel(size_hint_y=None, height=dp(20)))  # Отступ
        
        # Кнопка входа через Госуслуги (только на экране входа)
        if self.is_login:
            gosuslugi_btn = MDRaisedButton(
                text="Войти через Госуслуги",
                size_hint_y=None,
                height=dp(50),
                md_bg_color=[0.2, 0.6, 0.9, 1],  # Синий цвет Госуслуг
                icon="shield-account"
            )
            gosuslugi_btn.bind(on_release=self.handle_gosuslugi_login)
            content.add_widget(gosuslugi_btn)
            
            # Разделитель
            divider = MDLabel(
                text="или",
                theme_text_color="Secondary",
                font_style="Body2",
                halign="center",
                size_hint_y=None,
                height=dp(30)
            )
            content.add_widget(divider)
        
        # Карточка формы
        form_card = MDCard(
            orientation='vertical',
            padding=dp(25),
            spacing=dp(20),
            size_hint_y=None,
            radius=[dp(25), dp(25), dp(25), dp(25)],
            elevation=2
        )
        form_card.bind(minimum_height=form_card.setter('height'))
        
        # Поле ФИО (только для регистрации)
        if not self.is_login:
            self.full_name_field = MDTextField(
                hint_text="ФИО (например: Иванов Иван Иванович)",
                mode="fill",
                size_hint_y=None,
                height=dp(60)
            )
            form_card.add_widget(self.full_name_field)
        
        # Поле имени пользователя
        self.username_field = MDTextField(
            hint_text="Имя пользователя",
            mode="fill",
            size_hint_y=None,
            height=dp(60)
        )
        form_card.add_widget(self.username_field)
        
        # Поле email
        self.email_field = MDTextField(
            hint_text="Email",
            mode="fill",
            size_hint_y=None,
            height=dp(60)
        )
        form_card.add_widget(self.email_field)
        
        # Поле телефона (только для регистрации)
        if not self.is_login:
            self.phone_field = MDTextField(
                hint_text="Телефон (необязательно)",
                mode="fill",
                size_hint_y=None,
                height=dp(60)
            )
            form_card.add_widget(self.phone_field)
        
        # Поле пароля
        self.password_field = MDTextField(
            hint_text="Пароль",
            mode="fill",
            password=True,
            size_hint_y=None,
            height=dp(60)
        )
        form_card.add_widget(self.password_field)
        
        # Кнопка входа/регистрации
        action_btn = MDRaisedButton(
            text="Войти" if self.is_login else "Зарегистрироваться",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.5, 0.3, 0.9, 1]
        )
        action_btn.bind(on_release=self.handle_auth)
        form_card.add_widget(action_btn)
        
        content.add_widget(form_card)
        
        # Переключение между входом и регистрацией
        switch_text = "Нет аккаунта? Зарегистрироваться" if self.is_login else "Уже есть аккаунт? Войти"
        switch_label = MDLabel(
            text=switch_text,
            theme_text_color="Primary",
            font_style="Body1",
            halign="center",
            size_hint_y=None,
            height=dp(40)
        )
        # Делаем метку кликабельной
        switch_label.bind(on_touch_down=lambda w, t: self.switch_mode(w) if w.collide_point(*t.pos) else False)
        content.add_widget(switch_label)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self):
        """Создание заголовка с кнопкой назад"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        # Кнопка назад
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],  # Фиолетовый цвет
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        # Пустое пространство
        spacer = MDLabel(
            text="",
            size_hint_x=1
        )
        header.add_widget(spacer)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def switch_mode(self, instance):
        """Переключение между входом и регистрацией"""
        self.is_login = not self.is_login
        self.clear_widgets()
        self.build_ui()
    
    def handle_gosuslugi_login(self, instance):
        """Обработка входа через Госуслуги"""
        # Анимация кнопки
        anim = Animation(md_bg_color=[0.1, 0.5, 0.8, 1], duration=0.1) + \
               Animation(md_bg_color=[0.2, 0.6, 0.9, 1], duration=0.1)
        anim.start(instance)
        
        # Показываем сообщение (функция не реализована)
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text="Вход через Госуслуги временно недоступен.\nФункция будет доступна в следующих версиях приложения.",
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
    
    def handle_auth(self, instance):
        """Обработка авторизации/регистрации"""
        username = self.username_field.text.strip()
        password = self.password_field.text.strip()
        
        if not username or not password:
            self.show_error("Заполните все обязательные поля")
            return
        
        if self.is_login:
            # Вход
            success, user_data = auth_manager.login(username, password)
            if success:
                self.show_success("Вход выполнен успешно!")
                # Обновляем главный экран и переходим на него
                Clock.schedule_once(lambda dt: self.update_main_screen(), 0.5)
            else:
                self.show_error("Неверное имя пользователя или пароль")
        else:
            # Регистрация
            full_name = self.full_name_field.text.strip() if hasattr(self, 'full_name_field') else ""
            email = self.email_field.text.strip()
            phone = self.phone_field.text.strip() if hasattr(self, 'phone_field') else None
            
            if not full_name:
                self.show_error("Введите ФИО")
                return
            if not email:
                self.show_error("Введите email")
                return
            
            success, user_id = auth_manager.register(username, full_name, email, password, phone)
            if success:
                self.show_success("Регистрация успешна! Теперь войдите в систему.")
                # Переключаемся на экран входа
                self.is_login = True
                self.clear_widgets()
                self.build_ui()
            else:
                self.show_error("Пользователь с таким именем или email уже существует")
    
    def show_error(self, message):
        """Показать ошибку"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text=message,
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
    
    def update_main_screen(self):
        """Обновить главный экран"""
        if hasattr(self.manager, 'get_screen'):
            main_screen = self.manager.get_screen('main')
            if main_screen:
                main_screen.clear_widgets()
                main_screen.build_ui()
        self.manager.current = 'main'
    
    def show_success(self, message):
        """Показать успех"""
        from kivymd.uix.dialog import MDDialog
        dialog = MDDialog(
            text=message,
            buttons=[
                MDRaisedButton(text="OK", on_release=lambda x: dialog.dismiss())
            ]
        )
        dialog.open()
