"""
Экран управления анализами
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton, MDFlatButton
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from datetime import datetime
import json


class TestsScreen(MDScreen):
    """Экран управления анализами"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'tests'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Мои анализы")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(15)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Кнопка добавления
        add_btn = MDRaisedButton(
            text="+ Записать анализ",
            size_hint_y=None,
            height=dp(50),
            md_bg_color=[0.5, 0.3, 0.9, 1]
        )
        add_btn.bind(on_release=self.show_add_test_dialog)
        content.add_widget(add_btn)
        
        content.add_widget(MDLabel(size_hint_y=None, height=dp(10)))
        
        # Список анализов
        tests = self.load_tests()
        if tests:
            for test in tests:
                test_card = self.create_test_card(test)
                content.add_widget(test_card)
        else:
            empty_label = MDLabel(
                text="Нет записанных анализов\nНажмите кнопку выше, чтобы добавить",
                theme_text_color="Secondary",
                font_style="Body1",
                halign="center",
                size_hint_y=None,
                height=dp(100)
            )
            content.add_widget(empty_label)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_test_card(self, test):
        """Создание карточки анализа"""
        card = MDCard(
            orientation='vertical',
            padding=dp(15),
            spacing=dp(10),
            size_hint_y=None,
            radius=[dp(15), dp(15), dp(15), dp(15)],
            elevation=2
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок с кнопкой удаления
        header = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        
        from kivy.core.window import Window
        name_width = (Window.width - dp(30)) * 0.7 - dp(20)
        
        name_label = MDLabel(
            text=test.get('name', 'Анализ'),
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            valign="middle",
            size_hint_x=0.7,
            text_size=(name_width, None)
        )
        header.add_widget(name_label)
        
        delete_btn = MDIconButton(
            icon="delete",
            theme_icon_color="Error",
            size_hint=(None, None),
            size=(dp(35), dp(35)),
            pos_hint={'center_y': 0.5}
        )
        delete_btn.bind(on_release=lambda x, t=test: self.delete_test(t))
        header.add_widget(delete_btn)
        
        card.add_widget(header)
        
        from kivy.core.window import Window
        card_text_width = Window.width - dp(30) - dp(30)
        
        # Дата
        date_label = MDLabel(
            text=f"Дата: {test.get('date', '')}",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(card_text_width, None)
        )
        card.add_widget(date_label)
        
        # Результат
        if test.get('result'):
            result_label = MDLabel(
                text=f"Результат: {test.get('result', '')}",
                theme_text_color="Secondary",
                font_style="Body2",
                halign="left",
                valign="top",
                size_hint_y=None,
                text_size=(card_text_width, None)
            )
            card.add_widget(result_label)
        
        # Статус
        status = test.get('status', 'Норма')
        status_color = [0.3, 0.9, 0.3, 1] if status == 'Норма' else [0.9, 0.3, 0.3, 1]
        status_label = MDLabel(
            text=f"Статус: {status}",
            theme_text_color="Custom",
            text_color=status_color,
            font_style="Body1",
            halign="left",
            valign="top",
            size_hint_y=None,
            text_size=(card_text_width, None)
        )
        card.add_widget(status_label)
        
        return card
    
    def show_add_test_dialog(self, instance):
        """Показать диалог добавления анализа"""
        from kivymd.uix.dialog import MDDialog
        from kivy.uix.boxlayout import BoxLayout
        
        content = BoxLayout(orientation='vertical', spacing=dp(10), size_hint_y=None, height=dp(300))
        
        name_field = MDTextField(
            hint_text="Название анализа (например: Общий анализ крови)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(name_field)
        
        date_field = MDTextField(
            hint_text="Дата (например: 15.01.2024)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(date_field)
        
        result_field = MDTextField(
            hint_text="Результат (необязательно)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(result_field)
        
        status_field = MDTextField(
            hint_text="Статус (Норма / Требует внимания)",
            mode="fill",
            size_hint_y=None,
            height=dp(50)
        )
        content.add_widget(status_field)
        
        dialog = MDDialog(
            title="Записать анализ",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(text="Отмена", on_release=lambda x: dialog.dismiss()),
                MDRaisedButton(
                    text="Сохранить",
                    on_release=lambda x: self.add_test(
                        name_field.text,
                        date_field.text,
                        result_field.text,
                        status_field.text,
                        dialog
                    )
                )
            ]
        )
        dialog.open()
    
    def add_test(self, name, date, result, status, dialog):
        """Добавить анализ"""
        if not name or not date:
            from kivymd.uix.dialog import MDDialog
            error_dialog = MDDialog(
                text="Заполните название и дату",
                buttons=[MDRaisedButton(text="OK", on_release=lambda x: error_dialog.dismiss())]
            )
            error_dialog.open()
            return
        
        if not status:
            status = "Норма"
        
        test = {
            'name': name,
            'date': date,
            'result': result,
            'status': status,
            'id': datetime.now().isoformat()
        }
        
        tests = self.load_tests()
        tests.insert(0, test)  # Добавляем в начало
        self.save_tests(tests)
        
        dialog.dismiss()
        # Обновляем экран
        self.clear_widgets()
        self.build_ui()
    
    def delete_test(self, test):
        """Удалить анализ"""
        tests = self.load_tests()
        tests = [t for t in tests if t.get('id') != test.get('id')]
        self.save_tests(tests)
        
        # Обновляем экран
        self.clear_widgets()
        self.build_ui()
    
    def load_tests(self):
        """Загрузить список анализов"""
        from utils.android_paths import get_data_path
        tests_file = get_data_path('tests.json')
        try:
            with open(tests_file, 'r', encoding='utf-8') as f:
                tests = json.load(f)
                # Сортируем по дате (новые первые)
                return sorted(tests, key=lambda x: x.get('date', ''), reverse=True)
        except:
            return []
    
    def save_tests(self, tests):
        """Сохранить список анализов"""
        from utils.android_paths import get_data_path
        tests_file = get_data_path('tests.json')
        with open(tests_file, 'w', encoding='utf-8') as f:
            json.dump(tests, f, ensure_ascii=False, indent=2)

