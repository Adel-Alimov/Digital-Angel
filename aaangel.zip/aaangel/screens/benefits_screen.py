"""
Экран информации о пенсиях и льготах
"""

from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp


class BenefitsScreen(MDScreen):
    """Экран информации о пенсиях и льготах"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = 'benefits'
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        from kivy.uix.boxlayout import BoxLayout
        
        main_layout = BoxLayout(orientation='vertical', spacing=0)
        
        # Заголовок
        header = self.create_header("Пенсия и льготы")
        main_layout.add_widget(header)
        
        # Контент
        scroll = ScrollView(do_scroll_x=False, do_scroll_y=True)
        content = MDBoxLayout(
            orientation='vertical',
            size_hint_y=None,
            padding=[dp(20), dp(20)],
            spacing=dp(20)
        )
        content.bind(minimum_height=content.setter('height'))
        
        # Информационная карточка
        info_card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2,
            md_bg_color=[0.5, 0.3, 0.9, 0.1]
        )
        info_card.bind(minimum_height=info_card.setter('height'))
        
        title = MDLabel(
            text="💼 Пенсия и льготы",
            theme_text_color="Primary",
            font_style="H5",
            halign="left",
            size_hint_y=None,
            height=dp(40),
            bold=True
        )
        info_card.add_widget(title)
        
        subtitle = MDLabel(
            text="Полезная информация о пенсиях, льготах и социальных выплатах",
            theme_text_color="Secondary",
            font_style="Body2",
            halign="left",
            size_hint_y=None,
            height=dp(50),
            text_size=(None, None)
        )
        info_card.add_widget(subtitle)
        
        content.add_widget(info_card)
        
        # Разделы
        sections = [
            {
                'icon': '💰',
                'title': 'Как проверить пенсию',
                'steps': [
                    '1. Войдите на портал Госуслуги (gosuslugi.ru)',
                    '2. Найдите раздел "Пенсия, пособия и льготы"',
                    '3. Выберите "Информация о пенсионном обеспечении"',
                    '4. Вы увидите размер пенсии и дату следующей выплаты',
                    '5. Также можно проверить через мобильное приложение ПФР'
                ]
            },
            {
                'icon': '🏥',
                'title': 'Льготы на лекарства',
                'steps': [
                    '1. Обратитесь к врачу в поликлинике',
                    '2. Врач выпишет рецепт на льготные лекарства',
                    '3. С рецептом идите в аптеку, участвующую в программе',
                    '4. Предъявите паспорт, полис ОМС и рецепт',
                    '5. Получите лекарства бесплатно или со скидкой'
                ]
            },
            {
                'icon': '🚌',
                'title': 'Льготы на проезд',
                'steps': [
                    '1. Оформите социальную карту в МФЦ или через Госуслуги',
                    '2. Для пенсионеров - бесплатный проезд в общественном транспорте',
                    '3. Льготы на проезд в пригородных поездах',
                    '4. Скидки на междугородние поездки',
                    '5. Уточните льготы в вашем регионе в отделе соцзащиты'
                ]
            },
            {
                'icon': '🏠',
                'title': 'Льготы на ЖКУ',
                'steps': [
                    '1. Обратитесь в отдел соцзащиты по месту жительства',
                    '2. Предоставьте документы: паспорт, справку о доходах',
                    '3. Напишите заявление на субсидию',
                    '4. Если доход ниже прожиточного минимума - получите субсидию',
                    '5. Льготы начисляются автоматически при наличии права'
                ]
            },
            {
                'icon': '📞',
                'title': 'Полезные телефоны',
                'steps': [
                    'Пенсионный фонд: 8-800-302-2-302 (бесплатно)',
                    'Соцзащита: уточните в вашем городе',
                    'Горячая линия Госуслуг: 8-800-100-70-10',
                    'Справочная МФЦ: уточните в вашем городе'
                ]
            }
        ]
        
        for section in sections:
            section_card = self.create_section_card(section)
            content.add_widget(section_card)
        
        scroll.add_widget(content)
        main_layout.add_widget(scroll)
        
        self.add_widget(main_layout)
    
    def create_header(self, title):
        """Создание заголовка"""
        from kivy.uix.boxlayout import BoxLayout
        
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(80),
            padding=[dp(10), dp(10), dp(10), dp(10)],
            spacing=dp(10)
        )
        
        back_btn = MDIconButton(
            icon="arrow-left",
            theme_icon_color="Custom",
            icon_color=[0.5, 0.3, 0.9, 1],
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        back_btn.bind(on_release=self.go_back)
        header.add_widget(back_btn)
        
        title_label = MDLabel(
            text=title,
            theme_text_color="Primary",
            font_style="H5",
            bold=True,
            halign="left",
            size_hint_x=1
        )
        header.add_widget(title_label)
        
        return header
    
    def go_back(self, instance):
        """Переход на главный экран"""
        if self.manager:
            self.manager.current = 'main'
    
    def create_section_card(self, section):
        """Создание карточки раздела"""
        card = MDCard(
            orientation='vertical',
            padding=dp(20),
            spacing=dp(15),
            size_hint_y=None,
            radius=[dp(20), dp(20), dp(20), dp(20)],
            elevation=2
        )
        card.bind(minimum_height=card.setter('height'))
        
        # Заголовок
        header = MDBoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(40))
        
        icon_label = MDLabel(
            text=section['icon'],
            theme_text_color="Primary",
            font_style="H4",
            halign="left",
            size_hint_x=None,
            width=dp(50)
        )
        header.add_widget(icon_label)
        
        from kivy.core.window import Window
        title_width = Window.width - dp(40) - dp(40) - dp(50)  # padding + icon
        
        title_label = MDLabel(
            text=section['title'],
            theme_text_color="Primary",
            font_style="H6",
            halign="left",
            valign="middle",
            size_hint_x=1,
            bold=True,
            text_size=(title_width, None)
        )
        header.add_widget(title_label)
        
        card.add_widget(header)
        
        # Шаги
        step_width = Window.width - dp(40) - dp(40)  # padding content + padding card
        for step in section['steps']:
            step_label = MDLabel(
                text=step,
                theme_text_color="Secondary",
                font_style="Body2",
                halign="left",
                valign="top",
                size_hint_y=None,
                text_size=(step_width, None)
            )
            card.add_widget(step_label)
        
        return card

