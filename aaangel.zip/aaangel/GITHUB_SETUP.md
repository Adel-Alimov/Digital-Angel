# 📤 Пошаговая инструкция: Загрузка на GitHub и сборка APK

## Шаг 1: Создание репозитория на GitHub

1. Зайдите на https://github.com
2. Войдите в свой аккаунт (или создайте новый)
3. Нажмите **"+"** в правом верхнем углу → **"New repository"**
4. Заполните:
   - **Repository name**: `aaangel` (или любое другое имя)
   - **Description**: "Цифровой Ангел - Мобильное приложение"
   - Выберите **Public** или **Private**
   - **НЕ** ставьте галочки на "Add README", "Add .gitignore" и т.д.
5. Нажмите **"Create repository"**

---

## Шаг 2: Загрузка кода на GitHub

### Способ A: Через GitHub Desktop (Самый простой!)

1. **Скачайте GitHub Desktop**: https://desktop.github.com
2. **Установите** и войдите в свой аккаунт
3. **File** → **Add Local Repository**
4. Выберите папку: `c:\Users\DemrizZ\Documents\соц проект\aaangel`
5. Если появится предупреждение, нажмите **"create a repository"**
6. Внизу введите:
   - **Summary**: "Initial commit"
   - Нажмите **"Commit to main"**
7. Нажмите **"Publish repository"**
8. Выберите ваш репозиторий и нажмите **"Publish repository"**

### Способ B: Через Git (если установлен)

```powershell
# Откройте PowerShell в папке проекта
cd "c:\Users\DemrizZ\Documents\соц проект\aaangel"

# Инициализация Git
git init

# Добавление всех файлов
git add .

# Первый коммит
git commit -m "Initial commit"

# Переименование ветки
git branch -M main

# Добавление удаленного репозитория (замените YOUR_USERNAME на ваш логин)
git remote add origin https://github.com/YOUR_USERNAME/aaangel.git

# Загрузка на GitHub
git push -u origin main
```

### Способ C: Через веб-интерфейс GitHub

1. В созданном репозитории нажмите **"uploading an existing file"**
2. Перетащите все файлы из папки проекта
3. Внизу введите **"Initial commit"**
4. Нажмите **"Commit changes"**

---

## Шаг 3: Запуск сборки APK

1. Зайдите в ваш репозиторий на GitHub
2. Перейдите во вкладку **"Actions"** (вверху)
3. Если видите предупреждение, нажмите **"I understand my workflows, go ahead and enable them"**
4. Слева выберите **"Build Android APK"**
5. Нажмите **"Run workflow"** (справа)
6. Нажмите зеленую кнопку **"Run workflow"**
7. Дождитесь завершения (30-60 минут)

---

## Шаг 4: Скачивание APK

1. После завершения сборки (зеленая галочка) нажмите на задачу
2. Прокрутите вниз до раздела **"Artifacts"**
3. Нажмите на **"android-apk"**
4. Скачайте ZIP архив
5. Распакуйте - внутри будет APK файл!

---

## 🔄 Обновление кода и пересборка

После изменения кода:

### Через GitHub Desktop:
1. Внесите изменения в код
2. В GitHub Desktop внизу введите описание изменений
3. Нажмите **"Commit to main"**
4. Нажмите **"Push origin"**
5. Перейдите в **Actions** → **Run workflow**

### Через Git:
```powershell
git add .
git commit -m "Описание изменений"
git push
```

---

## ✅ Готово!

Теперь у вас есть:
- ✅ Код на GitHub (резервная копия)
- ✅ Автоматическая сборка APK
- ✅ Готовый APK для установки на телефон

---

## 🐛 Решение проблем

### Проблема: "Workflow не запускается"
**Решение**: Убедитесь, что файл `.github/workflows/build_apk.yml` загружен на GitHub

### Проблема: "Ошибка при сборке"
**Решение**: 
- Проверьте логи в GitHub Actions
- Убедитесь, что все файлы проекта загружены
- Проверьте, что `buildozer.spec` корректен

### Проблема: "Artifacts не найдены"
**Решение**: 
- Убедитесь, что сборка завершилась успешно (зеленая галочка)
- Подождите несколько минут после завершения

---

**Удачи! 🚀**
