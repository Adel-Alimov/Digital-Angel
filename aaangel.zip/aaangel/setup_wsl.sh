#!/bin/bash
# Скрипт для установки зависимостей и сборки APK в WSL2

echo "========================================"
echo "Установка зависимостей для сборки APK"
echo "========================================"
echo

# Проверка, что мы в WSL/Ubuntu
if [ ! -f /etc/os-release ]; then
    echo "Ошибка: Этот скрипт должен запускаться в WSL2/Ubuntu"
    exit 1
fi

# Обновление системы
echo "Обновление списка пакетов..."
sudo apt update

# Установка зависимостей
echo "Установка зависимостей..."
sudo apt install -y \
    git zip unzip openjdk-17-jdk \
    python3-pip python3-venv \
    autoconf libtool pkg-config \
    zlib1g-dev libncurses5-dev \
    libncursesw5-dev libtinfo5 \
    cmake libffi-dev libssl-dev \
    build-essential

# Установка buildozer
echo "Установка buildozer..."
pip3 install --user buildozer

# Добавление в PATH
export PATH=$PATH:~/.local/bin
echo 'export PATH=$PATH:~/.local/bin' >> ~/.bashrc

echo
echo "========================================"
echo "Зависимости установлены!"
echo "========================================"
echo
echo "Теперь можно запустить сборку:"
echo "  buildozer android debug"
echo
