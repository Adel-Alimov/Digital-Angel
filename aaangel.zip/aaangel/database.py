"""
База данных для хранения пользователей
"""

import sqlite3
import hashlib
from datetime import datetime
import os


class Database:
    """Класс для работы с базой данных"""
    
    def __init__(self, db_name='angel_users.db'):
        from utils.android_paths import get_data_path
        self.db_name = get_data_path(db_name)
        self.init_database()
    
    def get_connection(self):
        """Получить соединение с БД"""
        return sqlite3.connect(self.db_name)
    
    def init_database(self):
        """Инициализация базы данных"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                full_name TEXT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                phone TEXT,
                created_at TEXT NOT NULL
            )
        ''')
        
        # Добавляем колонку full_name если её нет (для существующих БД)
        try:
            cursor.execute('ALTER TABLE users ADD COLUMN full_name TEXT')
        except:
            pass
        try:
            cursor.execute('ALTER TABLE users ADD COLUMN phone TEXT')
        except:
            pass
        
        # Таблица данных о здоровье
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS health_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                steps INTEGER DEFAULT 0,
                heart_rate INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password):
        """Хеширование пароля"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_user(self, username, full_name, email, password, phone=None):
        """Регистрация нового пользователя"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            password_hash = self.hash_password(password)
            created_at = datetime.now().isoformat()
            
            cursor.execute('''
                INSERT INTO users (username, full_name, email, password_hash, phone, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (username, full_name, email, password_hash, phone, created_at))
            
            conn.commit()
            user_id = cursor.lastrowid
            conn.close()
            return True, user_id
        except sqlite3.IntegrityError:
            conn.close()
            return False, None
    
    def login_user(self, username, password):
        """Авторизация пользователя"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        password_hash = self.hash_password(password)
        
        cursor.execute('''
            SELECT id, username, full_name, email, phone FROM users
            WHERE username = ? AND password_hash = ?
        ''', (username, password_hash))
        
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return True, {
                'id': user[0],
                'username': user[1],
                'full_name': user[2] or user[1],  # Если ФИО нет, используем username
                'email': user[3],
                'phone': user[4] or ''
            }
        return False, None
    
    def get_user_by_id(self, user_id):
        """Получить пользователя по ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, full_name, email, phone FROM users
            WHERE id = ?
        ''', (user_id,))
        
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return {
                'id': user[0],
                'username': user[1],
                'full_name': user[2] or user[1],
                'email': user[3],
                'phone': user[4] or ''
            }
        return None
    
    def save_health_data(self, user_id, date, steps=None, heart_rate=None):
        """Сохранение данных о здоровье"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Проверяем, есть ли данные за этот день
        cursor.execute('''
            SELECT id FROM health_data
            WHERE user_id = ? AND date = ?
        ''', (user_id, date))
        
        existing = cursor.fetchone()
        
        if existing:
            # Обновляем существующие данные
            updates = []
            values = []
            if steps is not None:
                updates.append('steps = ?')
                values.append(steps)
            if heart_rate is not None:
                updates.append('heart_rate = ?')
                values.append(heart_rate)
            
            if updates:
                values.append(existing[0])
                cursor.execute(f'''
                    UPDATE health_data
                    SET {', '.join(updates)}
                    WHERE id = ?
                ''', values)
        else:
            # Создаем новую запись
            cursor.execute('''
                INSERT INTO health_data (user_id, date, steps, heart_rate)
                VALUES (?, ?, ?, ?)
            ''', (user_id, date, steps or 0, heart_rate or 0))
        
        conn.commit()
        conn.close()
    
    def get_health_data(self, user_id, days=7):
        """Получить данные о здоровье за последние дни"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT date, steps, heart_rate FROM health_data
            WHERE user_id = ?
            ORDER BY date DESC
            LIMIT ?
        ''', (user_id, days))
        
        data = cursor.fetchall()
        conn.close()
        
        return [{'date': row[0], 'steps': row[1], 'heart_rate': row[2]} for row in data]

