# 🚀 Быстрая инструкция по сборке APK

## ✅ Что уже исправлено для Android:

1. ✅ **Пути к файлам** - создан `utils/android_paths.py` для правильной работы на Android
2. ✅ **Зависимости** - обновлены в `buildozer.spec` (kivy>=2.3.0, kivymd>=1.2.0, plyer)
3. ✅ **Разрешения** - добавлены POST_NOTIFICATIONS, VIBRATE, WAKE_LOCK для уведомлений
4. ✅ **Файлы** - MD файлы включены в сборку, JSON файлы используют правильные пути
5. ✅ **База данных** - использует правильные пути на Android

## 📦 Быстрая сборка (Linux/WSL2):

```bash
# 1. Установите зависимости (один раз)
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev build-essential

# 2. Установите Buildozer (один раз)
pip3 install --user buildozer
export PATH=$PATH:~/.local/bin

# 3. Перейдите в папку проекта
cd "путь/к/проекту/aaangel"

# 4. Соберите APK (первый раз займет 30-60 минут)
buildozer android debug

# 5. APK будет в папке bin/
ls bin/*.apk
```

## 📲 Установка на телефон:

### Вариант 1: Через USB
```bash
# Включите "Отладка по USB" на телефоне
adb install bin/angel-0.1-arm64-v8a-debug.apk
```

### Вариант 2: Вручную
1. Скопируйте APK на телефон
2. Откройте файл и установите

## ⚠️ Важно:

- **Первая сборка** займет 30-60 минут (это нормально!)
- **Размер APK** будет 50-100 МБ
- **Минимальная версия Android**: 5.0 (API 21)
- **Рекомендуется**: Android 8.0+ (API 26+) для лучшей работы уведомлений

## 🔍 Что проверить после установки:

- ✅ Приложение запускается
- ✅ Все экраны работают
- ✅ Сохранение таблеток работает
- ✅ Уведомления приходят
- ✅ Настройки сохраняются

---

**Подробная инструкция:** см. `BUILD_ANDROID.md`
