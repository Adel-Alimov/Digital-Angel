"""
Тестовый файл для проверки позиционирования графиков
Запустите: python test_chart_positioning.py
"""

from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from kivy.graphics import Color, Line, Rectangle
from kivy.metrics import dp
from kivy.clock import Clock


class TestChart(Widget):
    """Тестовый виджет графика"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        self.height = dp(200)
        self.bind(size=self.update_chart, pos=self.update_chart)
        Clock.schedule_once(lambda dt: self.update_chart(None, None), 0.3)
    
    def update_chart(self, instance, value):
        """Обновление графика"""
        if self.width == 0 or self.height == 0:
            return
        
        self.canvas.clear()
        
        # Параметры области графика
        padding = dp(15)
        graph_width = max(1, self.width - (padding * 2))
        graph_height = max(1, self.height - (padding * 2))
        graph_x = padding
        graph_y = padding
        
        # Тестовые данные
        data = [180, 175, 170, 185, 190, 185, 180]
        max_val = max(data)
        min_val = min(data)
        range_val = max_val - min_val if max_val != min_val else 1
        
        with self.canvas:
            # ФОН ГРАФИКА (светлый фиолетовый)
            Color(0.5, 0.3, 0.9, 0.3)
            Rectangle(
                pos=(graph_x, graph_y),
                size=(graph_width, graph_height)
            )
            
            # ЛИНИЯ ГРАФИКА (темный фиолетовый)
            Color(0.5, 0.3, 0.9, 1)
            if len(data) > 1:
                points = []
                step = graph_width / (len(data) - 1)
                
                for i, val in enumerate(data):
                    # X координата - равномерно распределена
                    x = graph_x + (i * step)
                    
                    # Y координата - нормализована и инвертирована
                    normalized = (val - min_val) / range_val if range_val > 0 else 0.5
                    # Инвертируем: высокие значения сверху, низкие снизу
                    y = graph_y + ((1 - normalized) * graph_height)
                    
                    points.extend([x, y])
                
                if len(points) >= 4:
                    Line(points=points, width=dp(3))
            
            # ОТЛАДОЧНЫЕ ЛИНИИ - границы области графика
            Color(1, 0, 0, 0.5)  # Красный для границ
            # Верхняя граница
            Line(points=[graph_x, graph_y + graph_height, 
                        graph_x + graph_width, graph_y + graph_height], width=dp(1))
            # Нижняя граница
            Line(points=[graph_x, graph_y, 
                        graph_x + graph_width, graph_y], width=dp(1))
            # Левая граница
            Line(points=[graph_x, graph_y, 
                        graph_x, graph_y + graph_height], width=dp(1))
            # Правая граница
            Line(points=[graph_x + graph_width, graph_y, 
                        graph_x + graph_width, graph_y + graph_height], width=dp(1))


class TestScreen(MDScreen):
    """Тестовый экран"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """Построение интерфейса"""
        main_layout = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(20))
        
        # Инструкция
        from kivymd.uix.label import MDLabel
        instruction = MDLabel(
            text="Проверка позиционирования графика\nКрасные линии - границы области графика\nГрафик должен быть внутри красных линий",
            theme_text_color="Primary",
            font_style="H6",
            halign="center",
            size_hint_y=None,
            height=dp(100)
        )
        main_layout.add_widget(instruction)
        
        # Тестовый график
        test_chart = TestChart()
        main_layout.add_widget(test_chart)
        
        self.add_widget(main_layout)


class TestApp(MDApp):
    """Тестовое приложение"""
    
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Purple"
        return TestScreen()


if __name__ == '__main__':
    TestApp().run()

