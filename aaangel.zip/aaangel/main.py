"""
Цифровой Ангел - Мобильное приложение для пенсионеров
Главный файл приложения
"""

from kivymd.app import MDApp
from kivymd.uix.screenmanager import MDScreenManager
from kivy.core.window import Window

# Импорт экранов
from screens.splash_screen import SplashScreen
from screens.main_screen import MainScreen
from screens.auth_screen import AuthScreen
from screens.doctor_screen import DoctorScreen
from screens.profile_screen import ProfileScreen
from screens.health_screen import HealthScreen
from screens.pills_screen import PillsScreen
from screens.tests_screen import TestsScreen
from screens.doctor_guide_screen import DoctorGuideScreen
from screens.benefits_screen import BenefitsScreen
from screens.medical_help_screen import MedicalHelpScreen

# Импорт менеджера настроек
from utils.settings_manager import settings_manager


class AngelApp(MDApp):
    """Главный класс приложения"""
    
    def build(self):
        """Создание интерфейса приложения"""
        # Настройка темы
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Purple"  # Фиолетовая палитра
        self.theme_cls.accent_palette = "Purple"
        
        # Настройка размера окна для разработки (для Android будет полноэкранный)
        from kivy.utils import platform
        if platform != 'android':
            Window.size = (360, 640)  # Стандартный размер мобильного экрана (только для разработки)
        
        # Создание менеджера экранов
        sm = MDScreenManager()
        sm.transition.duration = 0.3
        
        # Добавление экранов
        sm.add_widget(SplashScreen(name='splash'))
        sm.add_widget(MainScreen(name='main'))
        sm.add_widget(AuthScreen(name='auth'))
        sm.add_widget(DoctorScreen(name='doctor'))
        sm.add_widget(ProfileScreen(name='profile'))
        sm.add_widget(HealthScreen(name='health'))
        sm.add_widget(PillsScreen(name='pills'))
        sm.add_widget(TestsScreen(name='tests'))
        sm.add_widget(DoctorGuideScreen(name='doctor_guide'))
        sm.add_widget(BenefitsScreen(name='benefits'))
        sm.add_widget(MedicalHelpScreen(name='medical_help'))
        
        # Устанавливаем начальный экран - splash screen
        sm.current = 'splash'
        
        return sm
    
    def on_start(self):
        """Выполняется при запуске приложения"""
        # Применяем настройки при запуске
        self.apply_settings()
        
        # Обновляем главный экран если пользователь авторизован
        from auth_manager import auth_manager
        if auth_manager.is_authenticated():
            main_screen = self.root.get_screen('main')
            if main_screen:
                main_screen.clear_widgets()
                main_screen.build_ui()
            
            # Запускаем уведомления о таблетках
            pills_screen = self.root.get_screen('pills')
            if pills_screen:
                pills_screen.start_notification_check()
    
    def apply_settings(self):
        """Применение настроек приложения"""
        # Применяем режим для слабовидящих
        if settings_manager.accessibility_mode:
            self.theme_cls.primary_palette = "Blue"
        else:
            self.theme_cls.primary_palette = "Purple"
        
        # Подписываемся на изменения настроек
        settings_manager.bind(
            font_size_scale=self.on_settings_changed,
            accessibility_mode=self.on_settings_changed
        )
    
    def on_settings_changed(self, *args):
        """Обработка изменения настроек"""
        # Применяем режим для слабовидящих
        if settings_manager.accessibility_mode:
            self.theme_cls.primary_palette = "Blue"
            self.theme_cls.accent_palette = "Blue"
        else:
            self.theme_cls.primary_palette = "Purple"
            self.theme_cls.accent_palette = "Purple"
        
        # Применяем настройки к текущему экрану без пересоздания
        if hasattr(self, 'root') and self.root:
            current_screen = self.root.current_screen
            if current_screen:
                try:
                    # Используем миксин если доступен
                    if hasattr(current_screen, 'apply_settings_to_widgets'):
                        current_screen.apply_settings_to_widgets()
                    else:
                        # Иначе применяем напрямую
                        from utils.font_helper import apply_font_size_to_widget
                        from utils.accessibility_helper import apply_accessibility_to_widget
                        for child in current_screen.children:
                            apply_font_size_to_widget(child)
                            if settings_manager.accessibility_mode:
                                apply_accessibility_to_widget(child)
                except Exception as e:
                    print(f"Ошибка при применении настроек: {e}")


if __name__ == '__main__':
    AngelApp().run()

