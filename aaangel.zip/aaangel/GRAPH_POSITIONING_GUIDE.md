# Руководство по позиционированию графиков

## Где находятся графики в коде

Графики создаются в файле `screens/health_screen.py` в двух методах:
1. `create_simple_chart()` - график анализов (строка ~903)
2. `create_pressure_chart()` - график давления (строка ~966)

## Основные параметры для изменения позиции

### 1. Отступы от краев (padding)

```python
padding = dp(10)  # ← ИЗМЕНИТЕ ЭТО ЗНАЧЕНИЕ
```

**Что делает:**
- Увеличить `padding` → график сдвинется **внутрь** (вправо и вверх)
- Уменьшить `padding` → график сдвинется **наружу** (влево и вниз)

**Примеры:**
```python
padding = dp(20)  # Больше отступ = график ближе к центру
padding = dp(5)   # Меньше отступ = график ближе к краям
```

### 2. Начальная позиция графика (graph_x, graph_y)

```python
graph_x = padding  # ← ИЗМЕНИТЕ ДЛЯ ДВИЖЕНИЯ ВЛЕВО/ВПРАВО
graph_y = padding  # ← ИЗМЕНИТЕ ДЛЯ ДВИЖЕНИЯ ВВЕРХ/ВНИЗ
```

**Что делает:**
- `graph_x` - горизонтальная позиция (влево/вправо)
- `graph_y` - вертикальная позиция (вверх/вниз)

**Примеры:**
```python
# Сдвинуть график вправо на 20 пикселей
graph_x = padding + dp(20)

# Сдвинуть график влево на 10 пикселей
graph_x = padding - dp(10)

# Сдвинуть график вверх на 30 пикселей
graph_y = padding + dp(30)

# Сдвинуть график вниз на 15 пикселей
graph_y = padding - dp(15)
```

### 3. Размер области графика

```python
graph_width = chart.width - (padding * 2)   # Ширина
graph_height = chart.height - (padding * 2) # Высота
```

**Что делает:**
- Увеличить `graph_width` → график станет шире
- Увеличить `graph_height` → график станет выше

**Примеры:**
```python
# Увеличить ширину графика
graph_width = chart.width - (padding * 2) + dp(40)

# Уменьшить высоту графика
graph_height = chart.height - (padding * 2) - dp(20)
```

### 4. Высота виджета графика

```python
chart = Widget(size_hint_y=None, height=dp(200))  # ← ИЗМЕНИТЕ ВЫСОТУ
```

**Что делает:**
- Увеличить `height` → график займет больше места по вертикали
- Уменьшить `height` → график займет меньше места

**Примеры:**
```python
chart = Widget(size_hint_y=None, height=dp(250))  # Выше
chart = Widget(size_hint_y=None, height=dp(150))  # Ниже
```

## Конкретные места в коде для изменения

### График анализов (create_simple_chart)

**Строка ~918-922:**
```python
# Параметры области графика
padding = dp(10)                    # ← ОТСТУПЫ (влево/вправо/вверх/вниз)
graph_width = chart.width - (padding * 2)
graph_height = chart.height - (padding * 2)
graph_x = padding                   # ← ГОРИЗОНТАЛЬНАЯ ПОЗИЦИЯ
graph_y = padding                   # ← ВЕРТИКАЛЬНАЯ ПОЗИЦИЯ
```

**Строка ~910:**
```python
chart = Widget(size_hint_y=None, height=dp(200))  # ← ВЫСОТА ВИДЖЕТА
```

**Строка ~908:**
```python
chart_container = MDBoxLayout(..., height=dp(230))  # ← ВЫСОТА КОНТЕЙНЕРА
```

### График давления (create_pressure_chart)

**Строка ~991-995:**
```python
# Параметры области графика
padding = dp(10)                    # ← ОТСТУПЫ
graph_width = chart.width - (padding * 2)
graph_height = chart.height - (padding * 2)
graph_x = padding                   # ← ГОРИЗОНТАЛЬНАЯ ПОЗИЦИЯ
graph_y = padding                   # ← ВЕРТИКАЛЬНАЯ ПОЗИЦИЯ
```

**Строка ~973:**
```python
chart = Widget(size_hint_y=None, height=dp(200))  # ← ВЫСОТА ВИДЖЕТА
```

**Строка ~971:**
```python
chart_container = MDBoxLayout(..., height=dp(230))  # ← ВЫСОТА КОНТЕЙНЕРА
```

## Быстрые примеры изменений

### Сдвинуть график вправо на 30px
```python
graph_x = padding + dp(30)
```

### Сдвинуть график влево на 20px
```python
graph_x = padding - dp(20)
```

### Сдвинуть график вверх на 40px
```python
graph_y = padding + dp(40)
```

### Сдвинуть график вниз на 25px
```python
graph_y = padding - dp(25)
```

### Увеличить отступы (график ближе к центру)
```python
padding = dp(30)  # Было dp(10)
```

### Уменьшить отступы (график ближе к краям)
```python
padding = dp(5)  # Было dp(10)
```

### Сделать график выше
```python
chart = Widget(size_hint_y=None, height=dp(250))  # Было dp(200)
chart_container = MDBoxLayout(..., height=dp(280))  # Было dp(230)
```

### Сделать график ниже
```python
chart = Widget(size_hint_y=None, height=dp(150))  # Было dp(200)
chart_container = MDBoxLayout(..., height=dp(180))  # Было dp(230)
```

## Важно!

После изменения кода нужно:
1. Сохранить файл
2. Перезапустить приложение: `python main.py`
3. Проверить результат

Если график не обновляется, попробуйте увеличить задержку обновления:
```python
Clock.schedule_once(lambda dt: update_chart(chart, None), 0.3)  # Было 0.2
```

