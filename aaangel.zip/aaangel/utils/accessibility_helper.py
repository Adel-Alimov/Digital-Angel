"""
Утилита для применения настроек доступности
"""

from kivy.metrics import dp
from utils.settings_manager import settings_manager


def apply_accessibility_to_widget(widget):
    """
    Применить настройки доступности к виджету и его дочерним элементам
    
    Args:
        widget: Виджет для применения настроек
    """
    if not settings_manager.accessibility_mode:
        # Если режим выключен, восстанавливаем оригинальные размеры
        if hasattr(widget, '_base_height') and hasattr(widget, 'height'):
            widget.height = widget._base_height
        if hasattr(widget, '_base_padding') and hasattr(widget, 'padding'):
            widget.padding = widget._base_padding
        return
    
    # Режим для слабовидящих: увеличиваем размеры элементов
    scale = 1.3  # Увеличение на 30%
    
    # Увеличиваем размеры кнопок и элементов интерфейса
    if hasattr(widget, 'height') and widget.height and widget.height > 0:
        if not hasattr(widget, '_base_height'):
            widget._base_height = widget.height
        widget.height = widget._base_height * scale
    
    # Увеличиваем padding для лучшей читаемости
    if hasattr(widget, 'padding'):
        if isinstance(widget.padding, (list, tuple)) and len(widget.padding) >= 2:
            if not hasattr(widget, '_base_padding'):
                widget._base_padding = widget.padding
            widget.padding = [p * scale for p in widget._base_padding]
        elif isinstance(widget.padding, (int, float)):
            if not hasattr(widget, '_base_padding'):
                widget._base_padding = widget.padding
            widget.padding = widget._base_padding * scale
    
    # Увеличиваем spacing
    if hasattr(widget, 'spacing'):
        if not hasattr(widget, '_base_spacing'):
            widget._base_spacing = widget.spacing
        widget.spacing = widget._base_spacing * scale
    
    # Применяем к дочерним виджетам
    if hasattr(widget, 'children'):
        for child in widget.children:
            apply_accessibility_to_widget(child)


def apply_font_size_to_widget(widget):
    """
    Применить размер текста к виджету и его дочерним элементам
    
    Args:
        widget: Виджет для применения размера шрифта
    """
    scale = settings_manager.get_font_scale()
    
    # Применяем к самому виджету если это Label или имеет font_size
    if hasattr(widget, 'font_size'):
        if widget.font_size:
            # Сохраняем базовый размер если еще не сохранен
            if not hasattr(widget, '_base_font_size'):
                widget._base_font_size = widget.font_size
            # Применяем масштаб
            widget.font_size = widget._base_font_size * scale
    
    # Для MDLabel применяем через font_style если возможно
    if hasattr(widget, 'font_style') and hasattr(widget, 'theme_font_styles'):
        # MDLabel использует font_style, нужно применять через изменение размера
        if hasattr(widget, 'font_size'):
            if not hasattr(widget, '_base_font_size'):
                # Получаем базовый размер из font_style
                from kivymd.app import MDApp
                app = MDApp.get_running_app()
                if app:
                    base_size = app.theme_cls.font_styles.get(widget.font_style, {}).get('font_size', 16)
                    widget._base_font_size = base_size
                    widget.font_size = base_size * scale
    
    # Применяем к дочерним виджетам
    if hasattr(widget, 'children'):
        for child in widget.children:
            apply_font_size_to_widget(child)
