"""
Утилита для применения размера текста ко всем виджетам
"""

from kivy.metrics import sp, dp
from utils.settings_manager import settings_manager


def get_font_size(base_size):
    """
    Получить размер шрифта с учетом настроек пользователя
    
    Args:
        base_size: Базовый размер шрифта в sp
        
    Returns:
        Размер шрифта с учетом масштаба
    """
    scale = settings_manager.get_font_scale()
    return base_size * scale


def get_base_font_size_from_style(font_style):
    """Получить базовый размер шрифта из стиля"""
    # Стандартные размеры для Material Design
    font_sizes = {
        'H1': 96,
        'H2': 60,
        'H3': 48,
        'H4': 34,
        'H5': 24,
        'H6': 20,
        'Subtitle1': 16,
        'Subtitle2': 14,
        'Body1': 16,
        'Body2': 14,
        'Button': 14,
        'Caption': 12,
        'Overline': 10,
    }
    return font_sizes.get(font_style, 16)


def apply_font_size_to_widget(widget):
    """
    Применить размер шрифта к виджету и его дочерним элементам
    
    Args:
        widget: Виджет для применения размера шрифта
    """
    scale = settings_manager.get_font_scale()
    
    # Для MDLabel - получаем базовый размер из font_style и применяем масштаб
    if hasattr(widget, 'font_style') and hasattr(widget, 'text'):
        # Получаем базовый размер из font_style
        if not hasattr(widget, '_base_font_size'):
            # Пытаемся получить из темы
            from kivymd.app import MDApp
            try:
                app = MDApp.get_running_app()
                if app and hasattr(app.theme_cls, 'font_styles'):
                    font_styles = app.theme_cls.font_styles
                    if widget.font_style in font_styles:
                        style_info = font_styles[widget.font_style]
                        if isinstance(style_info, dict):
                            base_size = style_info.get('font_size', get_base_font_size_from_style(widget.font_style))
                        else:
                            base_size = get_base_font_size_from_style(widget.font_style)
                    else:
                        base_size = get_base_font_size_from_style(widget.font_style)
                else:
                    base_size = get_base_font_size_from_style(widget.font_style)
            except:
                base_size = get_base_font_size_from_style(widget.font_style)
            
            widget._base_font_size = base_size
        
        # Применяем масштаб напрямую к font_size
        if hasattr(widget, '_base_font_size'):
            widget.font_size = widget._base_font_size * scale
    
    # Для виджетов с font_size напрямую (но без font_style)
    elif hasattr(widget, 'font_size') and widget.font_size and not hasattr(widget, 'font_style'):
        if not hasattr(widget, '_base_font_size'):
            widget._base_font_size = widget.font_size
        widget.font_size = widget._base_font_size * scale
    
    # Применяем к дочерним виджетам
    if hasattr(widget, 'children'):
        for child in widget.children:
            apply_font_size_to_widget(child)
