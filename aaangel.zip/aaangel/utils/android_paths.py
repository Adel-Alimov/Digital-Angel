"""
Утилита для получения правильных путей к файлам на Android
"""

import os
from kivy.utils import platform

def get_data_path(filename):
    """
    Получить путь к файлу данных, который работает на всех платформах
    
    Args:
        filename: Имя файла
        
    Returns:
        Полный путь к файлу
    """
    if platform == 'android':
        # На Android используем путь к внутреннему хранилищу приложения
        try:
            from jnius import autoclass
            
            # Получаем путь к внутреннему хранилищу приложения
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            context = PythonActivity.mActivity.getApplicationContext()
            files_dir = context.getFilesDir()
            data_path = os.path.join(str(files_dir), filename)
            return data_path
        except Exception as e:
            # Если не удалось, используем текущую директорию
            print(f"Ошибка получения пути на Android: {e}")
            return filename
    else:
        # На других платформах используем текущую директорию
        return filename


def get_resource_path(filename):
    """
    Получить путь к ресурсному файлу (MD файлы и т.д.)
    
    Args:
        filename: Имя файла
        
    Returns:
        Полный путь к файлу
    """
    if platform == 'android':
        # На Android ресурсы должны быть в assets или в пакете
        # Пытаемся найти в текущей директории или в assets
        if os.path.exists(filename):
            return filename
        # Пытаемся найти в assets
        assets_path = os.path.join('assets', filename)
        if os.path.exists(assets_path):
            return assets_path
        return filename
    else:
        # На других платформах используем текущую директорию
        return filename
