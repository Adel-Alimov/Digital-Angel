"""
Менеджер настроек приложения
"""

from kivy.storage.jsonstore import JsonStore
from kivy.properties import NumericProperty, BooleanProperty
from kivy.event import EventDispatcher


class SettingsManager(EventDispatcher):
    """Менеджер настроек приложения"""
    
    # Регистрируем событие
    __events__ = ('on_settings_changed',)
    
    # Размер текста от 1 до 10 (по умолчанию 5)
    font_size_scale = NumericProperty(5)
    
    # Режим для слабовидящих (по умолчанию выключен)
    accessibility_mode = BooleanProperty(False)
    
    def __init__(self):
        super().__init__()
        self._loading = True  # Флаг загрузки
        self.store = JsonStore('app_settings.json')
        self.load_settings()
        self._loading = False
        # Подписываемся на изменения свойств после загрузки
        self.bind(font_size_scale=self._on_setting_changed)
        self.bind(accessibility_mode=self._on_setting_changed)
    
    def load_settings(self):
        """Загрузка настроек из файла"""
        try:
            if 'font_size_scale' in self.store:
                self.font_size_scale = self.store.get('font_size_scale')['value']
            if 'accessibility_mode' in self.store:
                self.accessibility_mode = self.store.get('accessibility_mode')['value']
        except:
            # Если файл не существует или ошибка, используем значения по умолчанию
            pass
    
    def save_settings(self):
        """Сохранение настроек в файл"""
        try:
            self.store.put('font_size_scale', value=self.font_size_scale)
            self.store.put('accessibility_mode', value=self.accessibility_mode)
        except Exception as e:
            print(f"Ошибка при сохранении настроек: {e}")
    
    def _on_setting_changed(self, instance, value):
        """Внутренний обработчик изменения настроек"""
        # Не сохраняем и не отправляем события во время загрузки
        if self._loading:
            return
        self.save_settings()
        self.dispatch('on_settings_changed')
    
    def set_font_size(self, value):
        """Установка размера текста (1-10)"""
        if 1 <= value <= 10:
            self.font_size_scale = value
    
    def set_accessibility_mode(self, value):
        """Установка режима для слабовидящих"""
        self.accessibility_mode = value
    
    def get_font_scale(self):
        """Получить коэффициент масштабирования шрифта"""
        # Масштаб от 0.7 (для 1) до 1.5 (для 10)
        return 0.7 + (self.font_size_scale - 1) * (1.5 - 0.7) / 9
    
    def on_settings_changed(self, *args):
        """Событие изменения настроек"""
        pass


# Глобальный экземпляр менеджера настроек
settings_manager = SettingsManager()
