"""
Кастомный переключатель темы
"""

from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.animation import Animation
from kivy.metrics import dp
from kivy.properties import BooleanProperty


class ThemeSwitch(Widget):
    """Кастомный переключатель темы"""
    
    active = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (dp(50), dp(30))
        self.bind(active=self.update_switch)
        # Убираем bind на size и pos чтобы избежать бесконечных обновлений
        # Будем обновлять только при изменении active
        self.update_switch()
    
    def update_switch(self, *args):
        """Обновление внешнего вида переключателя"""
        if not hasattr(self, 'canvas'):
            return
        
        self.canvas.clear()
        
        with self.canvas:
            # Фон переключателя
            if self.active:
                Color(0.5, 0.3, 0.9, 1)  # Фиолетовый когда активен
            else:
                Color(0.5, 0.5, 0.5, 0.5)  # Серый когда неактивен
            
            RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(15), dp(15), dp(15), dp(15)]
            )
            
            # Кружок переключателя
            Color(1, 1, 1, 1)  # Белый
            if self.active:
                # Справа
                Ellipse(
                    pos=(self.x + self.width - dp(26), self.y + dp(2)),
                    size=(dp(26), dp(26))
                )
            else:
                # Слева
                Ellipse(
                    pos=(self.x + dp(2), self.y + dp(2)),
                    size=(dp(26), dp(26))
                )
    
    def on_size(self, instance, value):
        """Обновление при изменении размера"""
        self.update_switch()
    
    def on_pos(self, instance, value):
        """Обновление при изменении позиции"""
        self.update_switch()
    
    def on_touch_down(self, touch):
        """Обработка нажатия"""
        if self.collide_point(*touch.pos):
            self.active = not self.active
            return True
        return False

