"""
Миксин для применения настроек ко всем экранам
"""

from utils.font_helper import apply_font_size_to_widget
from utils.accessibility_helper import apply_accessibility_to_widget
from utils.settings_manager import settings_manager


class SettingsMixin:
    """Миксин для применения настроек к экранам"""
    
    def apply_settings_to_widgets(self):
        """Применить настройки ко всем виджетам на экране без пересоздания UI"""
        # Сохраняем позицию прокрутки если есть ScrollView
        scroll_positions = {}
        def save_scroll_positions(widget):
            if hasattr(widget, 'scroll_y'):
                scroll_positions[id(widget)] = widget.scroll_y
            if hasattr(widget, 'children'):
                for child in widget.children:
                    save_scroll_positions(child)
        
        def restore_scroll_positions(widget):
            if hasattr(widget, 'scroll_y') and id(widget) in scroll_positions:
                widget.scroll_y = scroll_positions[id(widget)]
            if hasattr(widget, 'children'):
                for child in widget.children:
                    restore_scroll_positions(child)
        
        # Сохраняем позиции прокрутки
        for child in self.children:
            save_scroll_positions(child)
        
        def apply_to_widget_tree(widget):
            """Рекурсивно применяем настройки к виджетам"""
            # Применяем размер текста
            apply_font_size_to_widget(widget)
            
            # Применяем режим доступности
            if settings_manager.accessibility_mode:
                apply_accessibility_to_widget(widget)
            
            # Применяем к дочерним виджетам
            if hasattr(widget, 'children'):
                for child in widget.children:
                    apply_to_widget_tree(child)
        
        # Применяем ко всем виджетам на экране
        try:
            for child in self.children:
                apply_to_widget_tree(child)
            
            # Восстанавливаем позиции прокрутки
            for child in self.children:
                restore_scroll_positions(child)
        except Exception as e:
            print(f"Ошибка при применении настроек: {e}")
