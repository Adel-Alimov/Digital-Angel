"""
Менеджер авторизации
"""

from database import Database
from kivy.storage.jsonstore import JsonStore


class AuthManager:
    """Класс для управления авторизацией"""
    
    def __init__(self):
        self.db = Database()
        self.store = JsonStore('user_session.json')
        self.current_user = None
        self.load_session()
    
    def load_session(self):
        """Загрузка сессии пользователя"""
        try:
            if 'user_id' in self.store:
                user_id = self.store.get('user_id')['value']
                # Загружаем полные данные пользователя из БД
                user_data = self.db.get_user_by_id(user_id)
                if user_data:
                    self.current_user = user_data
                else:
                    self.current_user = None
        except:
            self.current_user = None
    
    def save_session(self, user_data):
        """Сохранение сессии пользователя"""
        self.store.put('user_id', value=user_data['id'])
        self.store.put('username', value=user_data['username'])
        self.store.put('full_name', value=user_data.get('full_name', user_data['username']))
        self.store.put('email', value=user_data['email'])
        self.store.put('phone', value=user_data.get('phone', ''))
        self.current_user = user_data
    
    def clear_session(self):
        """Очистка сессии"""
        try:
            self.store.clear()
        except:
            pass
        self.current_user = None
    
    def is_authenticated(self):
        """Проверка авторизации"""
        return self.current_user is not None
    
    def get_current_user(self):
        """Получить текущего пользователя"""
        return self.current_user
    
    def register(self, username, full_name, email, password, phone=None):
        """Регистрация"""
        return self.db.register_user(username, full_name, email, password, phone)
    
    def login(self, username, password):
        """Вход"""
        success, user_data = self.db.login_user(username, password)
        if success:
            self.save_session(user_data)
        return success, user_data
    
    def logout(self):
        """Выход"""
        self.clear_session()

# Глобальный экземпляр
auth_manager = AuthManager()

