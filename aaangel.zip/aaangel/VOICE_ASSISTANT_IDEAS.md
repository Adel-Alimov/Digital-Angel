# 🎤 Идеи реализации голосового помощника для "Цифровой Ангел"

## Обзор

Голосовой помощник - ключевая функция приложения для пожилых пользователей, которая позволит им взаимодействовать с приложением без необходимости набирать текст или искать нужные кнопки.

---

## 🎯 Варианты реализации

### 1. Vosk (Офлайн распознавание) ⭐ Рекомендуется для начала

#### Преимущества:
- ✅ Работает **полностью офлайн** - не требует интернета
- ✅ **Бесплатный** и открытый исходный код
- ✅ **Легковесный** - небольшие модели (50-200 МБ)
- ✅ **Быстрый** - низкая задержка распознавания
- ✅ Поддерживает **русский язык** из коробки
- ✅ Хорошо работает на **мобильных устройствах**

#### Недостатки:
- ❌ Требует загрузки модели (один раз)
- ❌ Менее точный для сложных фраз
- ❌ Не понимает контекст так хорошо, как онлайн-сервисы

#### Установка:
```bash
pip install vosk
```

#### Загрузка русской модели:
```bash
# Скачать модель с https://alphacephei.com/vosk/models
# Распаковать в папку проекта (например, models/vosk-model-ru-0.22)
```

#### Пример кода:
```python
import vosk
import json
import pyaudio

# Загрузка модели
model = vosk.Model("models/vosk-model-ru-0.22")
rec = vosk.KaldiRecognizer(model, 16000)

# Запись аудио
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=4000)

# Распознавание
while True:
    data = stream.read(4000)
    if rec.AcceptWaveform(data):
        result = json.loads(rec.Result())
        text = result.get("text", "")
        if text:
            print(f"Распознано: {text}")
            # Обработка команды
            process_command(text)
```

#### Интеграция с Kivy:
```python
from kivy.clock import Clock
from kivy.core.audio import SoundLoader

class VoiceRecorder:
    def __init__(self):
        self.model = vosk.Model("models/vosk-model-ru-0.22")
        self.rec = vosk.KaldiRecognizer(self.model, 16000)
        self.is_recording = False
    
    def start_recording(self):
        self.is_recording = True
        # Запуск записи в отдельном потоке
        Clock.schedule_once(self._record_audio, 0)
    
    def stop_recording(self):
        self.is_recording = False
        # Получение результата
        result = json.loads(self.rec.FinalResult())
        return result.get("text", "")
```

---

### 2. Yandex SpeechKit (Онлайн) ⭐ Рекомендуется для сложных запросов

#### Преимущества:
- ✅ **Высокая точность** распознавания
- ✅ Понимает **контекст** и **интонацию**
- ✅ **Российский сервис** - хорошая поддержка русского
- ✅ Есть **бесплатный тариф** (до 1000 запросов/день)
- ✅ Поддерживает **несколько форматов** аудио

#### Недостатки:
- ❌ Требует **интернет-соединение**
- ❌ Платный после бесплатного лимита
- ❌ Задержка из-за сетевого запроса

#### Регистрация:
1. Зарегистрироваться на [Yandex Cloud](https://cloud.yandex.ru/)
2. Создать сервисный аккаунт
3. Получить API-ключ

#### Пример кода:
```python
import requests
import base64

class YandexSTT:
    def __init__(self, api_key):
        self.api_key = api_key
        self.url = "https://stt.api.cloud.yandex.net/speech/v1/stt:recognize"
    
    def recognize(self, audio_file_path):
        with open(audio_file_path, 'rb') as f:
            audio_data = f.read()
        
        headers = {
            "Authorization": f"Api-Key {self.api_key}"
        }
        
        data = {
            "format": "lpcm",
            "sampleRateHertz": 16000,
            "lang": "ru-RU"
        }
        
        files = {
            "data": audio_data
        }
        
        response = requests.post(self.url, headers=headers, data=data, files=files)
        result = response.json()
        
        if "result" in result:
            return result["result"]
        else:
            return None
```

---

### 3. Google Speech-to-Text API

#### Преимущества:
- ✅ Очень **высокая точность**
- ✅ Поддерживает **множество языков**
- ✅ Хорошая **документация**

#### Недостатки:
- ❌ Требует интернет
- ❌ Платный (есть бесплатный лимит)
- ❌ Зависимость от Google сервисов

#### Пример:
```python
from google.cloud import speech

client = speech.SpeechClient()
config = speech.RecognitionConfig(
    encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
    sample_rate_hertz=16000,
    language_code="ru-RU",
)

with open(audio_file, "rb") as audio_file:
    content = audio_file.read()

audio = speech.RecognitionAudio(content=content)
response = client.recognize(config=config, audio=audio)

for result in response.results:
    print(f"Распознано: {result.alternatives[0].transcript}")
```

---

### 4. Гибридный подход ⭐⭐⭐ ЛУЧШИЙ ВАРИАНТ

#### Архитектура:

```
┌─────────────────────────────────────┐
│   Пользователь говорит команду      │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│   Запись аудио (Kivy Audio)          │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│   Определение типа запроса           │
└──────┬───────────────────┬───────────┘
       │                   │
       ▼                   ▼
┌──────────────┐   ┌──────────────┐
│ Простая      │   │ Сложная      │
│ команда      │   │ команда      │
│ (Vosk)       │   │ (Yandex)     │
└──────┬───────┘   └──────┬───────┘
       │                  │
       └────────┬─────────┘
                ▼
┌─────────────────────────────────────┐
│   Парсинг команды                    │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│   Выполнение действия                │
│   (переход на экран, заполнение формы)│
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│   Озвучка ответа (TTS)               │
└──────────────────────────────────────┘
```

#### Простые команды (Vosk):
- "Записаться к врачу"
- "Вызвать такси"
- "Оплатить ЖКУ"
- "Позвонить Марии"
- "Проверить новость"

#### Сложные команды (Yandex):
- "Записаться к терапевту на завтра в 10 утра"
- "Вызвать такси на улицу Ленина, дом 5"
- "Оплатить коммунальные услуги на сумму 2500 рублей"

---

## 🔊 Text-to-Speech (Озвучка ответов)

### Варианты:

#### 1. pyttsx3 (Офлайн) ⭐ Рекомендуется
```python
import pyttsx3

engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Скорость (слов в минуту)
engine.setProperty('volume', 0.9)  # Громкость (0.0-1.0)

# Настройка голоса (русский)
voices = engine.getProperty('voices')
for voice in voices:
    if 'russian' in voice.name.lower():
        engine.setProperty('voice', voice.id)
        break

engine.say("Запись к врачу оформлена успешно")
engine.runAndWait()
```

#### 2. gTTS (Google, онлайн)
```python
from gtts import gTTS
from kivy.core.audio import SoundLoader

def speak(text):
    tts = gTTS(text=text, lang='ru')
    tts.save("temp_audio.mp3")
    sound = SoundLoader.load("temp_audio.mp3")
    if sound:
        sound.play()
```

#### 3. Yandex TTS
```python
import requests

def yandex_tts(text, api_key):
    url = "https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize"
    headers = {"Authorization": f"Api-Key {api_key}"}
    data = {
        "text": text,
        "lang": "ru-RU",
        "voice": "jane",  # или "omazh", "zahar", "ermil"
        "format": "mp3"
    }
    
    response = requests.post(url, headers=headers, data=data)
    # Сохранение и воспроизведение
```

---

## 📝 Парсинг команд

### Простой парсер команд:

```python
class CommandParser:
    def __init__(self):
        self.commands = {
            "врач": {
                "keywords": ["врач", "доктор", "терапевт", "записаться"],
                "action": "open_doctor_screen"
            },
            "такси": {
                "keywords": ["такси", "машина", "поехать"],
                "action": "open_taxi_screen"
            },
            "жку": {
                "keywords": ["жку", "коммуналка", "оплатить", "квартплата"],
                "action": "open_utilities_screen"
            },
            "звонок": {
                "keywords": ["позвонить", "звонок", "видео"],
                "action": "open_video_call_screen"
            },
            "новость": {
                "keywords": ["новость", "проверить", "правда"],
                "action": "open_news_screen"
            }
        }
    
    def parse(self, text):
        text_lower = text.lower()
        
        # Поиск команды по ключевым словам
        for cmd_name, cmd_data in self.commands.items():
            for keyword in cmd_data["keywords"]:
                if keyword in text_lower:
                    return cmd_data["action"]
        
        return None
```

### Продвинутый парсер (с извлечением параметров):

```python
import re

class AdvancedCommandParser:
    def parse_appointment(self, text):
        # "Записаться к терапевту на завтра в 10 утра"
        doctor_match = re.search(r'к\s+(\w+)', text)
        date_match = re.search(r'(завтра|сегодня|послезавтра)', text)
        time_match = re.search(r'в\s+(\d+)\s*(утра|дня|вечера)', text)
        
        return {
            "doctor": doctor_match.group(1) if doctor_match else None,
            "date": date_match.group(1) if date_match else None,
            "time": time_match.group(1) if time_match else None
        }
```

---

## 🎨 UI для голосового помощника

### Кнопка микрофона:

```python
from kivymd.uix.button import MDFabButton
from kivy.animation import Animation

class VoiceButton(MDFabButton):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.icon = "microphone"
        self.md_bg_color = [0.9, 0.3, 0.6, 1]
        self.size_hint = (None, None)
        self.size = (dp(60), dp(60))
        self.pos_hint = {"center_x": 0.5, "y": 0.02}
        
        # Анимация пульсации при записи
        self.animation = None
    
    def start_recording(self):
        """Начало записи"""
        self.icon = "microphone"
        self.md_bg_color = [1.0, 0.2, 0.2, 1]  # Красный
        
        # Анимация пульсации
        self.animation = Animation(size=(dp(70), dp(70)), duration=0.5) + \
                        Animation(size=(dp(60), dp(60)), duration=0.5)
        self.animation.repeat = True
        self.animation.start(self)
    
    def stop_recording(self):
        """Остановка записи"""
        if self.animation:
            self.animation.cancel(self)
        
        self.icon = "microphone"
        self.md_bg_color = [0.9, 0.3, 0.6, 1]  # Розовый
        self.size = (dp(60), dp(60))
```

### Индикатор записи:

```python
from kivymd.uix.label import MDLabel
from kivy.graphics import Color, Ellipse

class RecordingIndicator(MDLabel):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.text = "🎤 Говорите..."
        self.theme_text_color = "Error"
        self.halign = "center"
        
        # Анимация мигания
        self.animation = Animation(opacity=0.3, duration=0.5) + \
                        Animation(opacity=1.0, duration=0.5)
        self.animation.repeat = True
```

---

## 📦 Структура модуля голосового помощника

```
utils/
└── voice/
    ├── __init__.py
    ├── voice_assistant.py      # Главный класс помощника
    ├── offline_recognizer.py    # Vosk распознавание
    ├── online_recognizer.py     # Yandex/Google распознавание
    ├── command_parser.py        # Парсинг команд
    ├── tts.py                   # Text-to-Speech
    └── audio_recorder.py        # Запись аудио
```

### Пример структуры:

```python
# utils/voice/voice_assistant.py

class VoiceAssistant:
    def __init__(self):
        self.offline_rec = OfflineRecognizer()
        self.online_rec = OnlineRecognizer()
        self.parser = CommandParser()
        self.tts = TTS()
        self.is_recording = False
    
    def start_listening(self):
        """Начать прослушивание"""
        self.is_recording = True
        # Запуск записи
    
    def process_command(self, text):
        """Обработка распознанной команды"""
        action = self.parser.parse(text)
        if action:
            # Выполнение действия
            self.execute_action(action)
            # Озвучка подтверждения
            self.tts.speak("Команда выполнена")
    
    def execute_action(self, action):
        """Выполнение действия"""
        # Переход на нужный экран или выполнение операции
        pass
```

---

## 🚀 План внедрения

### Этап 1: Базовая интеграция (1-2 недели)
1. ✅ Установка Vosk и загрузка русской модели
2. ✅ Создание модуля записи аудио
3. ✅ Реализация базового распознавания
4. ✅ Создание простого парсера команд
5. ✅ Добавление кнопки микрофона на главный экран

### Этап 2: Улучшение (2-3 недели)
1. ✅ Интеграция TTS для обратной связи
2. ✅ Улучшение парсера команд
3. ✅ Визуальная индикация записи
4. ✅ Обработка ошибок
5. ✅ Тестирование на реальных устройствах

### Этап 3: Продвинутые функции (3-4 недели)
1. ✅ Интеграция онлайн распознавания
2. ✅ Контекстные команды
3. ✅ Извлечение параметров из команд
4. ✅ Обучение на специфических командах
5. ✅ Оптимизация производительности

---

## 📚 Полезные ресурсы

- [Vosk Documentation](https://alphacephei.com/vosk/)
- [Vosk Models](https://alphacephei.com/vosk/models) - скачать русскую модель
- [Yandex SpeechKit](https://cloud.yandex.ru/docs/speechkit/)
- [Kivy Audio](https://kivy.org/doc/stable/api-kivy.core.audio.html)
- [pyttsx3 Documentation](https://pyttsx3.readthedocs.io/)

---

## ⚠️ Важные замечания

1. **Разрешения Android**: Убедитесь, что в `buildozer.spec` есть `RECORD_AUDIO`
2. **Размер модели**: Vosk модели могут быть большими (50-200 МБ), учитывайте при сборке APK
3. **Производительность**: Тестируйте на реальных устройствах, особенно на слабых
4. **Офлайн режим**: Vosk работает офлайн, но для онлайн-сервисов нужен интернет
5. **Приватность**: Голосовые данные не должны передаваться третьим лицам без согласия

---

**Рекомендация:** Начните с Vosk для базовых команд, затем добавьте Yandex SpeechKit для сложных запросов. Это даст лучший баланс между функциональностью и производительностью.

