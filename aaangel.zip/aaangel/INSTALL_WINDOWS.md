# 🪟 Установка на Windows

## Проблема с зависимостями

На Windows установка Kivy может вызвать проблемы из-за несовместимости версий зависимостей.

## Решение

### Вариант 1: Установка через pip (рекомендуется)

```powershell
# 1. Обновите pip
python -m pip install --upgrade pip

# 2. Установите зависимости для Windows
pip install kivy[base]
pip install kivymd
pip install requests
pip install Pillow
```

### Вариант 2: Установка конкретных версий

Если первый вариант не работает, попробуйте:

```powershell
# Установите зависимости в правильном порядке
pip install kivy_deps.sdl2==0.7.0
pip install kivy_deps.gstreamer==0.3.4
pip install kivy[base]>=2.3.0
pip install kivymd>=1.2.0
pip install requests
pip install Pillow
```

### Вариант 3: Использование предкомпилированных wheel

```powershell
# Установите wheel файлы напрямую
pip install --upgrade pip wheel setuptools
pip install kivy[base] --prefer-binary
pip install kivymd --prefer-binary
```

## Проверка установки

После установки проверьте:

```powershell
python -c "import kivy; print(kivy.__version__)"
python -c "import kivymd; print(kivymd.__version__)"
```

## Запуск приложения

```powershell
python main.py
```

## Если проблемы остаются

1. **Очистите кэш pip:**
```powershell
pip cache purge
```

2. **Переустановите в чистом окружении:**
```powershell
# Создайте новое виртуальное окружение
python -m venv venv_new
venv_new\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
```

3. **Используйте conda (альтернатива):**
```powershell
conda create -n angel python=3.11
conda activate angel
conda install -c conda-forge kivy
pip install kivymd requests Pillow
```

## Примечания

- На Windows рекомендуется использовать Python 3.10 или 3.11
- Убедитесь, что у вас установлен Visual C++ Redistributable
- Для сборки APK на Windows используйте WSL2 (Windows Subsystem for Linux)

