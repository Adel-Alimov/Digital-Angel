#!/bin/bash
# Скрипт для сборки APK

echo "========================================"
echo "Сборка APK для Android"
echo "========================================"
echo

# Проверка buildozer
if ! command -v buildozer &> /dev/null; then
    echo "Buildozer не найден. Установка..."
    pip3 install --user buildozer
    export PATH=$PATH:~/.local/bin
fi

# Переход в директорию проекта
cd "$(dirname "$0")"

echo "Текущая директория: $(pwd)"
echo

# Очистка предыдущих сборок (опционально)
read -p "Очистить предыдущие сборки? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Очистка..."
    buildozer android clean
    echo
fi

# Сборка APK
echo "Начало сборки APK..."
echo "Это может занять 30-60 минут при первой сборке..."
echo

buildozer android debug

if [ $? -eq 0 ]; then
    echo
    echo "========================================"
    echo "Сборка завершена успешно!"
    echo "========================================"
    echo
    echo "APK файлы находятся в папке bin/:"
    ls -lh bin/*.apk 2>/dev/null || echo "APK файлы не найдены"
    echo
else
    echo
    echo "========================================"
    echo "Ошибка при сборке"
    echo "========================================"
    echo
    echo "Проверьте ошибки выше и попробуйте снова"
    echo
fi
