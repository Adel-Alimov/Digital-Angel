# Цифровой Ангел - Мобильное приложение для пенсионеров

## 📱 Описание проекта

**Цифровой Ангел** - это мобильное приложение, разработанное специально для людей пожилого возраста (55+), которое помогает им легко и безопасно пользоваться цифровыми услугами.

### Основные функции:
- 🏥 **Запись к врачу** - упрощенная запись на прием к специалистам
- 🚕 **Вызов такси** - быстрый вызов такси с определением местоположения
- 💰 **Оплата ЖКУ** - безопасная оплата коммунальных услуг
- 📹 **Видеозвонки** - общение с родственниками и друзьями
- 📰 **Проверка новостей** - проверка достоверности информации
- 👤 **Профиль** - настройки и личная информация

## 🛠 Технологический стек

- **Python 3.9+**
- **Kivy 2.2.0** - фреймворк для создания кроссплатформенных приложений
- **KivyMD 1.1.1** - Material Design компоненты для Kivy
- **Buildozer** - инструмент для сборки Android APK

## 📋 Требования

### Для разработки:
- Python 3.9 или выше
- pip (менеджер пакетов Python)
- Git (опционально)

### Для сборки APK (Android):
- Linux или macOS (Windows через WSL)
- Buildozer
- Android SDK и NDK
- Java JDK

## 🚀 Установка и запуск

### 1. Клонирование репозитория (если используется Git)
```bash
git clone <repository-url>
cd aaangel
```

### 2. Создание виртуального окружения (рекомендуется)
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/macOS
source venv/bin/activate
```

### 3. Установка зависимостей
```bash
pip install -r requirements.txt
```

### 4. Запуск приложения
```bash
python main.py
```

## 📦 Сборка APK для Android

### Подготовка окружения

#### Linux (Ubuntu/Debian):
```bash
# Установка зависимостей
sudo apt update
sudo apt install -y git zip unzip openjdk-11-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev

# Установка Buildozer
pip install buildozer

# Установка Cython
pip install cython
```

#### macOS:
```bash
# Установка через Homebrew
brew install autoconf automake libtool pkg-config
brew install libffi openssl

# Установка Buildozer
pip install buildozer
pip install cython
```

#### Windows (через WSL):
1. Установите WSL2 и Ubuntu
2. Следуйте инструкциям для Linux

### Сборка APK

1. **Настройка buildozer.spec** (опционально):
   - Откройте `buildozer.spec`
   - При необходимости измените настройки (название, версия, иконка и т.д.)

2. **Первая сборка** (займет много времени, так как скачает все зависимости):
```bash
buildozer android debug
```

3. **Последующие сборки** (быстрее):
```bash
buildozer android debug
```

4. **Сборка release версии**:
```bash
buildozer android release
```

5. **Готовый APK** будет находиться в папке `bin/`:
   - `bin/angel-0.1-arm64-v8a-debug.apk` (для 64-битных устройств)
   - `bin/angel-0.1-armeabi-v7a-debug.apk` (для 32-битных устройств)

### Установка APK на устройство

1. Включите "Отладка по USB" в настройках Android
2. Подключите устройство к компьютеру
3. Установите через ADB:
```bash
adb install bin/angel-0.1-arm64-v8a-debug.apk
```

Или просто скопируйте APK на устройство и установите вручную.

## 📁 Структура проекта

```
aaangel/
├── main.py                 # Главный файл приложения
├── requirements.txt        # Зависимости Python
├── buildozer.spec         # Конфигурация для сборки APK
├── README.md              # Документация
├── screens/               # Экраны приложения
│   ├── __init__.py
│   ├── main_screen.py     # Главный экран
│   ├── doctor_screen.py   # Запись к врачу
│   ├── taxi_screen.py     # Вызов такси
│   ├── utilities_screen.py # Оплата ЖКУ
│   ├── video_call_screen.py # Видеозвонки
│   ├── news_screen.py     # Проверка новостей
│   └── profile_screen.py   # Профиль
├── utils/                 # Утилиты (будущие)
│   └── __init__.py
└── assets/                # Ресурсы (иконки, изображения)
```

## 🎨 Особенности дизайна

- **Крупные кнопки** - удобны для пожилых людей
- **Яркие цвета** - улучшают видимость
- **Простой интерфейс** - минимум элементов на экране
- **Анимации** - плавные переходы между экранами
- **Темная тема** - снижает нагрузку на глаза

## 🔮 Планы развития

### Ближайшие обновления:
- [ ] Интеграция с API записи к врачу
- [ ] Интеграция с сервисами такси
- [ ] Интеграция с платежными системами
- [ ] Реальная проверка новостей через API
- [ ] Видеозвонки через WebRTC

### Голосовой помощник:
См. раздел [Голосовой помощник](#голосовой-помощник) ниже.

## 🤝 Вклад в проект

Проект разрабатывается в рамках социальной инициативы. Приветствуются любые улучшения и предложения!

## 📄 Лицензия

Проект разработан для социальных целей.

## 👥 Контакты

**Руководитель проекта:** Алимов Адель Ильдусович  
**Студент ИСТ 2 курс**

---

## 🎤 Голосовой помощник

### Идеи реализации

#### 1. **Простое распознавание речи (Vosk)**

**Преимущества:**
- Работает офлайн
- Легковесная библиотека
- Поддерживает русский язык
- Не требует интернета

**Реализация:**
```python
# Установка
pip install vosk

# Пример использования
import vosk
import json

model = vosk.Model("model-ru")
rec = vosk.KaldiRecognizer(model, 16000)

# Обработка аудио
result = rec.Result()
text = json.loads(result)["text"]
```

**Интеграция:**
- Кнопка микрофона на главном экране
- Обработка команд: "Записаться к врачу", "Вызвать такси", "Оплатить ЖКУ"
- Простой синтаксический анализ команд

#### 2. **Google Speech-to-Text API**

**Преимущества:**
- Высокая точность
- Поддержка контекста
- Распознавание с учетом контекста приложения

**Недостатки:**
- Требует интернет
- Платный после бесплатного лимита
- Зависимость от Google сервисов

**Реализация:**
```python
from google.cloud import speech

client = speech.SpeechClient()
config = speech.RecognitionConfig(
    encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
    sample_rate_hertz=16000,
    language_code="ru-RU",
)
```

#### 3. **Yandex SpeechKit**

**Преимущества:**
- Российский сервис
- Хорошая поддержка русского языка
- Есть бесплатный тариф

**Реализация:**
```python
import requests

url = "https://stt.api.cloud.yandex.net/speech/v1/stt:recognize"
headers = {"Authorization": f"Api-Key {api_key}"}
data = {"format": "lpcm", "sampleRateHertz": 16000, "lang": "ru-RU"}
```

#### 4. **Гибридный подход (рекомендуется)**

**Архитектура:**
1. **Офлайн распознавание** (Vosk) для базовых команд:
   - "Записаться к врачу"
   - "Вызвать такси"
   - "Оплатить ЖКУ"
   - "Позвонить [имя]"

2. **Онлайн распознавание** (Yandex/Google) для:
   - Сложных запросов
   - Ввода адресов
   - Ввода данных для форм

**Структура кода:**
```
utils/
├── voice/
│   ├── __init__.py
│   ├── offline_recognizer.py  # Vosk для базовых команд
│   ├── online_recognizer.py   # Yandex/Google для сложных
│   ├── command_parser.py      # Парсинг команд
│   └── tts.py                 # Text-to-Speech (озвучка ответов)
```

#### 5. **Text-to-Speech (озвучка ответов)**

**Библиотеки:**
- **pyttsx3** - офлайн синтез речи (кроссплатформенный)
- **gTTS (Google)** - онлайн, требует интернет
- **Yandex TTS** - российский сервис

**Пример:**
```python
import pyttsx3

engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Скорость речи
engine.setProperty('volume', 0.9)  # Громкость
engine.say("Запись к врачу оформлена")
engine.runAndWait()
```

### Рекомендуемый план внедрения

#### Этап 1: Базовая интеграция (1-2 недели)
1. Установка Vosk и загрузка русской модели
2. Создание кнопки микрофона на главном экране
3. Реализация базового распознавания
4. Парсинг простых команд ("записаться к врачу", "вызвать такси")

#### Этап 2: Улучшение (2-3 недели)
1. Добавление TTS для обратной связи
2. Интеграция с экранами приложения
3. Обработка ошибок распознавания
4. Визуальная индикация (анимация при записи)

#### Этап 3: Продвинутые функции (3-4 недели)
1. Интеграция онлайн распознавания для сложных запросов
2. Контекстные команды ("записаться к терапевту на завтра")
3. Озвучка инструкций и подсказок
4. Обучение модели на специфических командах

### Пример кода голосового помощника

```python
# utils/voice/voice_assistant.py

import vosk
import json
import pyttsx3
from kivy.clock import Clock

class VoiceAssistant:
    def __init__(self):
        self.model = vosk.Model("model-ru")
        self.recognizer = None
        self.tts_engine = pyttsx3.init()
        self.commands = {
            "записаться к врачу": "doctor",
            "вызвать такси": "taxi",
            "оплатить жку": "utilities",
            "позвонить": "video_call",
            "проверить новость": "news"
        }
    
    def recognize_command(self, audio_data):
        """Распознавание команды из аудио"""
        if not self.recognizer:
            self.recognizer = vosk.KaldiRecognizer(self.model, 16000)
        
        if self.recognizer.AcceptWaveform(audio_data):
            result = json.loads(self.recognizer.Result())
            text = result.get("text", "").lower()
            
            # Поиск команды
            for cmd, screen in self.commands.items():
                if cmd in text:
                    return screen
        return None
    
    def speak(self, text):
        """Озвучивание текста"""
        self.tts_engine.say(text)
        self.tts_engine.runAndWait()
```

### Необходимые разрешения Android

В `buildozer.spec` уже добавлены:
```
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,CAMERA,RECORD_AUDIO,READ_PHONE_STATE
```

`RECORD_AUDIO` - необходимо для записи голоса.

### Дополнительные ресурсы

- [Документация Vosk](https://alphacephei.com/vosk/)
- [Yandex SpeechKit](https://cloud.yandex.ru/docs/speechkit/)
- [Kivy Audio](https://kivy.org/doc/stable/api-kivy.core.audio.html)

---

**Примечание:** Голосовой помощник пока не реализован в текущей версии, но архитектура готова для его интеграции.

